#!/bin/sh
# tak3-node: which folders under /home the node may see.
#
#   /usr/libexec/tak3-node/home-folders.sh <unit> <folder>...
#
# The package's units hide /home, /root and /run/user (ProtectHome). Setup
# still grants export, on-demand and recordings folders there, so this writes
# a drop-in for <unit> that keeps the rest hidden and binds in, read-write,
# each folder whose real path is under /home. With none, the drop-in goes.
# The only writer of that file: setup, the package's postinstall and every
# other caller run this, then systemctl daemon-reload, then restart the node.
#
# A folder whose name holds a newline is refused, and the drop-in stays as it
# was. A new drop-in that systemd-analyze verify finds fault with is taken
# back. A unit without ProtectHome (a script install's) gets none.
#
# Exit: 0 written, removed or not needed; 1 refused; 2 usage.
set -eu

ETC=${TAK3_SYSTEMD_ETC:-/etc/systemd/system}
LIB=${TAK3_SYSTEMD_LIB:-/lib/systemd/system}
NL='
'

say() { printf '  tak3-node: %s\n' "$1"; }
refuse() { printf '  tak3-node: %s\n' "$1" >&2; exit 1; }

[ $# -ge 1 ] || { echo "usage: home-folders.sh <unit> <folder>..." >&2; exit 2; }
unit=$1
shift
case "$unit" in *"$NL"*) refuse "not a tak3 node unit: $unit" ;; esac
printf '%s' "$unit" | grep -Eqx 'tak3-node(@[a-z][a-z0-9-]{0,15})?\.service' \
    || refuse "not a tak3 node unit: $unit"

dir=$ETC/$unit.d
dropin=$dir/home-folders.conf

remove() {
    if [ -f "$dropin" ]; then
        rm -f "$dropin"
        rmdir "$dir" 2>/dev/null || true
        say "$unit sees no folder under /home"
    fi
}

# The unit in effect: one in $ETC overrides the package's.
template=$LIB/tak3-node@.service
case "$unit" in tak3-node.service) template=$LIB/$unit ;; esac
if [ -f "$ETC/$unit" ] || [ -L "$ETC/$unit" ]; then
    effective=$ETC/$unit
elif [ -f "$LIB/$unit" ]; then
    effective=$LIB/$unit
else
    effective=$template
fi
if ! grep -qs '^ProtectHome=' "$effective"; then
    remove
    exit 0
fi

# Every folder is checked before anything changes.
for f in "$@"; do
    case "$f" in *"$NL"*) refuse "a folder name holds a newline; $dropin is left as it was" ;; esac
done

# A value for BindPaths=, in double quotes: systemd unquotes it, so \ and "
# are escaped, and expands specifiers in it, so % is doubled. A space or a
# colon inside the quotes is part of the name.
quote() {
    printf '"%s"' "$(printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/%/%%/g')"
}

lines=""
add() {
    case "$NL$lines" in *"$NL$1$NL"*) return 0 ;; esac
    lines="$lines$1$NL"
}
for f in "$@"; do
    case "$f" in /?*) ;; *) continue ;; esac
    # As the node names it, without a trailing slash.
    given=$(printf '%s' "$f" | sed -e 's|//*|/|g' -e 's|/$||')
    real=$(realpath -m -- "$f")
    case "$real" in
        /home/?*) add "BindPaths=$(quote "-$real")" ;;
    esac
    # A name in /home that leads out of it: the node still opens it by that name.
    case "$given" in
        /home/?*) [ "$given" = "$real" ] || add "BindPaths=$(quote "-$real"):$(quote "$given")" ;;
    esac
done

if [ -z "$lines" ]; then
    remove
    exit 0
fi

mkdir -p "$dir"
{
    echo "# Written by /usr/libexec/tak3-node/home-folders.sh, from the folders setup"
    echo "# granted; it writes this file again on each run and on each upgrade."
    echo "# /home, /root and /run/user stay empty for the node, except these folders."
    echo "[Service]"
    echo "ProtectHome=tmpfs"
    printf '%s' "$lines"
} > "$dropin.new"
chmod 644 "$dropin.new"
if [ -f "$dropin" ]; then cp -p "$dropin" "$dropin.old"; else rm -f "$dropin.old"; fi
mv "$dropin.new" "$dropin"

# verify UNIT — its findings, and 1 when it found fault.
verify() { systemd-analyze verify "$1" 2>&1; }
if command -v systemd-analyze >/dev/null 2>&1; then
    bad=""
    if found=$(verify "$unit"); then
        case "$found" in *"$dropin"*) bad=yes ;; esac
    else
        bad=yes
        case "$found" in *"$dropin"*) ;; *)
            # Fault elsewhere in the unit is not this file's: it stands if the
            # unit fails the same way without it.
            mv "$dropin" "$dropin.try"
            if [ -f "$dropin.old" ]; then cp -p "$dropin.old" "$dropin"; fi
            if ! verify "$unit" >/dev/null; then bad=""; fi
            mv "$dropin.try" "$dropin"
            ;;
        esac
    fi
    if [ -n "$bad" ]; then
        if [ -f "$dropin.old" ]; then mv "$dropin.old" "$dropin"; else rm -f "$dropin"; rmdir "$dir" 2>/dev/null || true; fi
        printf '%s\n' "$found" >&2
        refuse "systemd-analyze verify found fault with the folders under /home; $dropin is left as it was"
    fi
fi
rm -f "$dropin.old"
say "$unit sees these folders under /home: $(printf '%s' "$lines" | sed -e 's/^BindPaths=//' | tr '\n' ' ')"
