#!/bin/bash
#
# tak3 node installer, for a server running MediaMTX or Nimble Streamer.
#
# Two ways in, one script:
#   - copied to a server and run:   sudo bash install-node.sh [tak3-node-<version>.jar]
#   - from the package:             sudo tak3-node-setup
#     (apt install tak3-node puts the program in place; this asks the questions)
#   - a second node on the same machine, by name:
#                                   sudo tak3-node-setup --instance mtx
#     e.g. MediaMTX beside a Nimble that already has its node. It runs as
#     tak3-node@mtx with its own port, settings and state, MediaMTX gets ports
#     nothing else here uses, and the console shows it as a server of its own.
#   - and straight into the console, with a code an owner made there under
#     Servers › Add server:
#                                   sudo tak3-node-setup --pair https://console.example/pair/<code>
#     (--address https://host:port as well when the console must call this
#     node at an address setup cannot see, e.g. behind NAT. Pairing goes over
#     the tailnet, this machine, or HTTPS — see --https-port)
#
# Everything that must be exact — the Nimble salt/hash, the API keys, the
# MediaMTX download — is generated or checked ON this machine, so nothing has
# to be pasted through a console clipboard. The script refuses to write a
# credential it has not first proven works.
#
# Knobs (environment):
#   MEDIA=mediamtx|nimble  skip the question; otherwise it is detected
#   PORT=8090              listen port when 8080 is taken
#   TRANSCODE=no           skip Docker; this box never runs a ladder
#   IMAGE=...              ffmpeg image to use (default tak3/ffmpeg:6.1-alpine3.22, built here)
#   VOD_PORT=8081          where a MediaMTX node serves On demand files
#   MEDIAMTX_VERSION=...   which MediaMTX to install when there is none (default: the tested one)
#   INSTANCE=name          the same as --instance name
#   --listen ADDRESS       where the node's API answers: by default this machine's
#                          tailnet address (with a tailnet), else 127.0.0.1 only;
#                          --listen 0.0.0.0 puts it on every address, for a console
#                          that reaches it over the internet (then firewall it)
#   --certificate DOMAIN   its own small job: copy this server's certificate for
#                          DOMAIN (certbot's or the hosting panel's) to serve
#                          HTTPS with; or --certificate CHAIN KEY [--name N]
#   --https-port PORT      serve the API over HTTPS too, on every address, with
#   --https-name NAME      the copied certificate NAME (the only one, if omitted).
#                          For a console across the internet: pairing works there.
#                          --https-port off turns it off again
#   --record-folder PATH   where MediaMTX writes its recordings (MediaMTX nodes): the
#                          folder is made or opened to MediaMTX, set in its
#                          mediamtx.yml and applied without a restart; the
#                          recordings made so far can move with it
#   --mediamtx-tls on|off  MediaMTX over SSL with the same certificate: RTMPS for
#                          encoders, HTTPS for HLS and WebRTC (a website on https
#                          needs it to play live streams). On by default where
#                          there is a certificate; renewals are picked up by itself
#   --vod-https on|off     On demand files over HTTPS on their own port, with the
#                          copied certificate (MediaMTX nodes). On by default:
#                          setup asks for the name viewers use and copies its
#                          certificate. A website on https can only play files
#                          from an https address. off serves plain HTTP
#   --vod-folder PATH      allow on-demand files from this folder (repeatable). The
#                          console picks routes among the allowed folders only, and
#                          only audio, video and images are ever served from them
#   --export-folder PATH   allow exports into this folder (repeatable). Exports go
#                          nowhere else; by default the node's own mp4 folder and
#                          the on-demand folders
#   NEW_PUSH_SECRET=yes    a new key for Nimble's stream events, shown once (new
#                          Nimble nodes get one anyway): then update Nimble's push address
#   --new-keys             new full-control and read-only keys, shown once; every
#                          console holding the old ones must be given these (or pair
#                          again). For a console you think was taken over
#
# Safe to re-run: the service user, directories, Nimble settings, API keys and
# any setting added by hand are kept.
#
# The node's settings hold no secret of tak3's in the open: its API keys and the
# push secret are kept as digests (it only compares them), and the MediaMTX
# password and the console's push address are sealed with
# /etc/tak3-node/secret.key (root:tak3-node, 640). Nimble's own salt and hash
# are Nimble's, and stay as Nimble needs them.

set -euo pipefail

# A certificate for HTTPS is its own small job, not a re-run of setup. The copy
# is shared by every node on this machine, so an --instance given with it
# changes nothing and is left out.
CERT_JOB=""
for a in "$@"; do if [ "$a" = --certificate ]; then CERT_JOB=yes; fi; done
if [ -n "$CERT_JOB" ]; then
    CERT_ARGS=()
    SKIP=""
    for a in "$@"; do
        if [ -n "$SKIP" ]; then SKIP=""; continue; fi
        case "$a" in
            --instance) SKIP=yes ;;
            --instance=*|--certificate) ;;
            *) CERT_ARGS+=("$a") ;;
        esac
    done
    set -- "${CERT_ARGS[@]+"${CERT_ARGS[@]}"}"
    if [ -n "${TAK3_PACKAGED:-}" ]; then
        TAK3_FOR=node exec /usr/libexec/tak3-node/certificate "$@"
    fi
    TAK3_FOR=node exec bash "$(dirname "$0")/certificate.sh" "$@"
fi

PACKAGED=${TAK3_PACKAGED:-}
INSTANCE=${INSTANCE:-}
PAIR=${PAIR:-}
ADDRESS=${ADDRESS:-}
LISTEN=${LISTEN:-}
VOD_FOLDERS=${VOD_FOLDERS:-}
EXPORT_FOLDERS=${EXPORT_FOLDERS:-}
HTTPS_PORT=${HTTPS_PORT:-}
HTTPS_NAME=${HTTPS_NAME:-}
VOD_HTTPS=${VOD_HTTPS:-}
MTX_SSL=${MTX_SSL:-}
RECORD_FOLDER=${RECORD_FOLDER:-}
NEW_KEYS=${NEW_KEYS:-}
ARGS=()
while [ $# -gt 0 ]; do
    case "$1" in
        --instance) INSTANCE=${2-}; shift; [ $# -gt 0 ] && shift ;;
        --instance=*) INSTANCE=${1#*=}; shift ;;
        --pair) PAIR=${2-}; shift; [ $# -gt 0 ] && shift ;;
        --pair=*) PAIR=${1#*=}; shift ;;
        --address) ADDRESS=${2-}; shift; [ $# -gt 0 ] && shift ;;
        --address=*) ADDRESS=${1#*=}; shift ;;
        --vod-folder) VOD_FOLDERS="${VOD_FOLDERS:+$VOD_FOLDERS,}${2-}"; shift; [ $# -gt 0 ] && shift ;;
        --vod-folder=*) VOD_FOLDERS="${VOD_FOLDERS:+$VOD_FOLDERS,}${1#*=}"; shift ;;
        --export-folder) EXPORT_FOLDERS="${EXPORT_FOLDERS:+$EXPORT_FOLDERS,}${2-}"; shift; [ $# -gt 0 ] && shift ;;
        --export-folder=*) EXPORT_FOLDERS="${EXPORT_FOLDERS:+$EXPORT_FOLDERS,}${1#*=}"; shift ;;
        --https-port) HTTPS_PORT=${2-}; shift; [ $# -gt 0 ] && shift ;;
        --https-port=*) HTTPS_PORT=${1#*=}; shift ;;
        --https-name) HTTPS_NAME=${2-}; shift; [ $# -gt 0 ] && shift ;;
        --https-name=*) HTTPS_NAME=${1#*=}; shift ;;
        --vod-https) VOD_HTTPS=${2-}; shift; [ $# -gt 0 ] && shift ;;
        --vod-https=*) VOD_HTTPS=${1#*=}; shift ;;
        --mediamtx-tls) MTX_SSL=${2-}; shift; [ $# -gt 0 ] && shift ;;
        --mediamtx-tls=*) MTX_SSL=${1#*=}; shift ;;
        --record-folder) RECORD_FOLDER=${2-}; shift; [ $# -gt 0 ] && shift ;;
        --record-folder=*) RECORD_FOLDER=${1#*=}; shift ;;
        --listen) LISTEN=${2-}; shift; [ $# -gt 0 ] && shift ;;
        --listen=*) LISTEN=${1#*=}; shift ;;
        --new-keys) NEW_KEYS=yes; shift ;;
        *) ARGS+=("$1"); shift ;;
    esac
done
set -- "${ARGS[@]+"${ARGS[@]}"}"
SERVICE=tak3-node.service
SERVICE_USER=tak3-node
INSTALL_DIR=/var/lib/tak3-node
UNIT=/etc/systemd/system/$SERVICE
NIMBLE_CONF=/etc/nimble/nimble.conf
# Set from nimble.conf once it is located; 8082 is only Nimble's default and
# plenty of servers run the management API elsewhere.
MGMT=http://127.0.0.1:8082
DEFAULT_IMAGE=tak3/ffmpeg:6.1-alpine3.22
# Given, or what this server used before (read once the earlier settings are), or the default.
IMAGE=${IMAGE:-}
MEDIA=${MEDIA:-}
VOD_PORT=${VOD_PORT:-}
# The release this console was tested against. A newer one usually works; this
# is the one that is known to.
MEDIAMTX_VERSION=${MEDIAMTX_VERSION:-v1.21.2}
MTX_API=http://127.0.0.1:9997
# Containers are run through this root-owned helper, never through the docker group.
HELPER=/usr/libexec/tak3-node/tak3-docker
SUDOERS=/etc/sudoers.d/tak3-node

if [ -n "$PACKAGED" ]; then
    # The package owns the program, the runtime and the unit; this writes only
    # the configuration, which the package never touches.
    CONFIG=/etc/tak3-node/application.properties
    JAR=/opt/tak3-node/lib/tak3-node.jar
    ME=tak3-node-setup
    if [ -n "$INSTANCE" ]; then
        # A named node: the package's template unit, its own settings and state.
        SERVICE=tak3-node@$INSTANCE.service
        CONFIG=/etc/tak3-node/instances/$INSTANCE.properties
        INSTALL_DIR=/var/lib/tak3-node/instances/$INSTANCE
        ME="tak3-node-setup --instance $INSTANCE"
    fi
else
    CONFIG=""
    LINK="$INSTALL_DIR/tak3-node.jar"
    ME="bash $0"
fi
# The certificate job, which belongs to no one node.
CERT_ME=${ME%% --instance*}

# Progress: every heading says which step it is and what the step is for, so
# an operator watching an install knows how far along it is and whether what
# it is doing now is something they need to care about.
STEP=0
STEPS=9
say()  {
    STEP=$((STEP+1))
    printf '\n\033[1m[%d/%d] %s\033[0m\n' "$STEP" "$STEPS" "$1"
    [ $# -gt 1 ] && printf '      \033[2m%s\033[0m\n' "$2"
    return 0
}
ok()   { printf '   \033[32mok\033[0m  %s\n' "$1"; }
warn() { printf '   \033[33m!!\033[0m  %s\n' "$1"; }
die()  { printf '\n\033[31mFAILED: %s\033[0m\n' "$1" >&2; exit 1; }
hint() { printf '       \033[2m%s\033[0m\n' "$1"; }
# In a folder the service user owns, root does nothing by name: a link the
# service left there, for a file or for a whole folder such as scripts/, would
# lead root's write, copy or chown wherever it pointed. The service user does
# it instead, and reaches only what it could reach anyway.
as_service() { runuser -u "$SERVICE_USER" -- "$@"; }
# Root writing straight into the service's top folder, whose parent is root's:
# install(1) replaces whatever is at the path, a link included, instead of
# following it, and gives the new file its owner and mode.
place() {  # place SRC DEST OWNER MODE
    [ ! -L "$2" ] || die "$2 is a symbolic link — refusing to write through it"
    install -o "$3" -g "$3" -m "$4" -- "$1" "$2"
}
# A build the person running this put down: in their home, root's, this
# directory or this install's own folder, owned by them, root or the service,
# and writable by no one else. A jar left in /tmp or another user's home could
# be anyone's, and it would be installed and run.
find_jar() {  # find_jar PATTERN
    local me=${SUDO_USER:-root} home
    home=$(getent passwd "$me" | cut -d: -f6 || true)
    find ${home:+"$home"} /root "$PWD" "$INSTALL_DIR" -maxdepth 3 -type f -name "$1" \
        \( -uid 0 -o -uid "$(id -u "$me" 2>/dev/null || echo 0)" -o -uid "$(id -u "$SERVICE_USER" 2>/dev/null || echo 0)" \) \
        ! -perm -002 -print -quit 2>/dev/null || true
}
# 32 random bytes, base64url: safe in a header and in a URL.
newkey() { openssl rand -base64 32 | tr '+/' '-_' | tr -d '=\n'; }
# What the node keeps of a key: it only ever compares, so it never needs it back.
digest() { printf 'sha256:%s' "$(printf '%s' "$1" | sha256sum | cut -d' ' -f1)"; }
is_digest() { [[ $1 =~ ^sha256:[0-9a-fA-F]{64}$ ]]; }
# The key that seals what the node must read back; made in step 5.
SECRET_KEY=/etc/tak3-node/secret.key
is_sealed() { [[ $1 == sealed:v1:* ]]; }
# The jar seals and opens with that key; the value goes on standard input,
# never on a command line, where ps would show it.
node_java() { if [ -n "$PACKAGED" ]; then /opt/tak3-node/jre/bin/java "$@"; else java "$@"; fi; }
seal()   { printf '%s' "$1" | node_java -jar "$JAR" seal --key-file "$SECRET_KEY"; }
unseal() { printf '%s' "$1" | node_java -jar "$JAR" unseal --key-file "$SECRET_KEY"; }
yesno() {
    local __var=$1 __q=$2 __def=$3 __ans=""
    read -r -p "   $__q $([ "$__def" = y ] && echo '(Y/n)' || echo '(y/N)'): " __ans </dev/tty || __ans=""
    __ans=${__ans:-$__def}
    case "$__ans" in [Yy]*) printf -v "$__var" 'y';; *) printf -v "$__var" 'n';; esac
}

[ "$(id -u)" -eq 0 ] || die "run with sudo"
if [ -n "$PAIR" ]; then
    # https://console.example:8989/pair/ABCDE-FGHIJ-… — checked before anything
    # is changed, so a mistyped code costs nothing.
    [[ $PAIR =~ ^(https?://[^/[:space:]]+)/pair/([A-Za-z2-7-]{20,64})$ ]] \
        || die "--pair takes the address the console showed, like https://console.example/pair/ABCDE-FGHIJ-KLMNO-PQRST-UVWXY-Z"
    CONSOLE_URL=${BASH_REMATCH[1]}
    PAIR_CODE=${BASH_REMATCH[2]}
    # The node's key goes to the console with the code: never in clear text
    # across the internet. Plain http only to this machine or inside a tailnet.
    if [[ $CONSOLE_URL == http://* ]]; then
        host=${CONSOLE_URL#http://}; host=${host%%:*}
        if ! [[ $host == localhost || $host =~ ^127\. || $host =~ \.ts\.net$ \
                || $host =~ ^100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\. ]]; then
            die "the console's address is plain http, so this node's key would cross the network readable.
   Use its https address (the one with a certificate), or its tailnet address."
        fi
    fi
    if [ -n "$ADDRESS" ]; then
        [[ $ADDRESS =~ ^https?://[^/[:space:]]+:[0-9]+/?$ ]] || die "--address is how the console reaches this node, like https://node.example.com:8443 or http://100.101.102.103:8090"
        ADDRESS=${ADDRESS%/}
    fi
    STEPS=10
fi
if [ -n "$INSTANCE" ]; then
    # It ends up in a unit name, a container name and a label.
    [[ $INSTANCE =~ ^[a-z][a-z0-9-]{0,15}$ ]] && [ "$INSTANCE" != default ] \
        || die "a node's name is a lowercase letter, then up to 15 lowercase letters, digits or dashes (not 'default'): '$INSTANCE'"
    [ -n "$PACKAGED" ] || die "a second node on one machine needs the package: sudo apt install tak3-node, then sudo tak3-node-setup --instance $INSTANCE"
fi

# Ports: whether one is taken, and the first free one from a start. A port
# handed out in this run counts as taken, so two settings never get the same.
CLAIMED=" "
port_free() {
    case "$CLAIMED" in *" $1/$2 "*) return 1 ;; esac
    ! ss -H -l"$1"n "sport = :$2" 2>/dev/null | grep -q .
}
# first_free VAR t|u PORT — sets VAR; not $(…), whose subshell would forget the claim.
first_free() {
    local __var=$1 proto=$2 port=$3
    while ! port_free "$proto" "$port"; do port=$((port + 1)); done
    CLAIMED="$CLAIMED$proto/$port "
    printf -v "$__var" '%s' "$port"
}

cat <<'BANNER'

  tak3 node - setup
  -----------------
  Sets up the node beside the media server on this machine: it serves the
  status API the console polls, applies what the console changes, reconciles
  transcoder containers and, on Nimble, runs the per-stream scripts.

  On MediaMTX it installs MediaMTX too if there is none. On Nimble it reads
  /etc/nimble/nimble.conf, appends a management_token only if there is none,
  and never touches rules.conf, so whatever manages Nimble today keeps owning
  its applications, routes and recording.

  9 steps, a minute or two. At most three questions.

BANNER

# --- what was here before ---------------------------------------------------
# A re-run keeps every key and every setting added by hand. Where they come
# from: this node's configuration file (package), or the ExecStart line of the
# unit a script install wrote. A package set up over a script install takes
# them from that unit, which is how such a box moves to the package.
PREV_SRC=""
if [ -n "$PACKAGED" ] && [ -f "$CONFIG" ]; then PREV_SRC=props
elif [ -z "$INSTANCE" ] && [ -f "$UNIT" ] && grep -q '^ExecStart=' "$UNIT"; then PREV_SRC=unit
fi
# prev KEY — a setting's earlier value, or nothing.
prev() {
    local key=$1 v=""
    case "$PREV_SRC" in
        props) v=$(grep -m1 "^${key}=" "$CONFIG" 2>/dev/null | cut -d= -f2- || true) ;;
        unit)  v=$(grep -m1 '^ExecStart=' "$UNIT" | tr ' ' '\n' | grep -m1 -- "^--${key}=" | cut -d= -f2- || true) ;;
    esac
    # systemd strips quotes from ExecStart; a properties file has none to strip.
    v=${v#\'}; v=${v%\'}; v=${v#\"}; v=${v%\"}
    printf '%s' "$v"
}
# The settings this script writes. Anything else found before is kept as it was.
OURS=" scriptPath salt hash server.port server.address node.https.port node.https.certificate vod.https media.mediamtx.tls pushSecret vod.allowed-roots export.folders managementUrlAndPort web.authentication.apikey readOnlyApiKey transcoderEnabled transcoderStore transcoder.default-image transcoder.docker-command eventForwardUrl media.server vod.port media.mediamtx.user media.mediamtx.password node.instance transcoder.nimble-rtmp-url media.republish-source tak3.metrics.port "
CARRY=""
case "$PREV_SRC" in
    props)
        while IFS= read -r line; do
            case "$line" in ''|'#'*) continue ;; esac
            key=${line%%=*}
            case "$OURS" in *" $key "*) ;; *) CARRY="$CARRY
$line" ;; esac
        done < "$CONFIG" ;;
    unit)
        set -f
        for tok in $(grep -m1 '^ExecStart=' "$UNIT" | cut -d= -f2-); do
            case "$tok" in
                --*=*) key=${tok#--}; key=${key%%=*}
                    case "$OURS" in *" $key "*) ;; *) CARRY="$CARRY
${tok#--}" ;; esac ;;
                # A flag with no value (--debug) is kept as one with an empty value.
                --*) CARRY="$CARRY
${tok#--}=" ;;
            esac
        done
        set +f ;;
esac
PORT=${PORT:-$(prev server.port)}
if [ -n "$INSTANCE" ] && [ -z "$PORT" ]; then
    # Beside another node: the first port nothing here listens on.
    first_free PORT t 8090
fi
PORT=${PORT:-8080}
CLAIMED="$CLAIMED t/$PORT "
# An upgrade keeps the image and the On demand port the server already had.
IMAGE=${IMAGE:-$(prev transcoder.default-image)}
IMAGE=${IMAGE:-$DEFAULT_IMAGE}
VOD_PORT=${VOD_PORT:-$(prev vod.port)}
if [ -z "$VOD_PORT" ] && { [ -n "$INSTANCE" ] || [ -f "$NIMBLE_CONF" ]; }; then
    # 8081 is Nimble's own HTTP port.
    first_free VOD_PORT t 8081
fi
VOD_PORT=${VOD_PORT:-8081}
CLAIMED="$CLAIMED t/$VOD_PORT "
# Where its meters are served, on 127.0.0.1 only. The main node has the
# default, 9180, and needs no line; a node beside it gets a port of its own,
# the first from 9181 that no other node's settings name and nothing listens
# on. Without one it found 9180 taken and served no meters at all.
METRICS_PORT=$(prev tak3.metrics.port)
if [ -n "$INSTANCE" ] && [ -z "$METRICS_PORT" ]; then
    for other in /etc/tak3-node/application.properties /etc/tak3-node/instances/*.properties; do
        [ -f "$other" ] && [ "$other" != "$CONFIG" ] || continue
        named=$(grep -m1 '^tak3.metrics.port=' "$other" | cut -d= -f2- || true)
        [ -n "$named" ] && CLAIMED="$CLAIMED t/$named "
    done
    first_free METRICS_PORT t 9181
fi

# --- 1. the build -----------------------------------------------------------
if [ -n "$PACKAGED" ]; then
    say "The build" "installed by the package, with its own Java runtime"
    [ -f "$JAR" ] || die "$JAR is missing — reinstall the package: sudo apt install --reinstall tak3-node"
    ok "tak3-node $(dpkg-query -W -f='${Version}' tak3-node 2>/dev/null || echo '?')"
else
    say "Locating the jar" "the build being installed; it is copied into /var/lib/tak3-node and run through a stable symlink"
    JAR="${1:-}"
    if [ -z "$JAR" ]; then
        JAR=$(find_jar 'tak3-node-*.jar')
    fi
    [ -n "$JAR" ] && [ -f "$JAR" ] || die "jar not found — pass its path as the first argument"
    JAR_NAME=$(basename "$JAR")
    ok "$JAR"
fi

# --- 2. java and tools ------------------------------------------------------
if [ -n "$PACKAGED" ]; then
    say "Java 21 and tools" "the runtime comes with the package; curl, jq and unzip from the distribution"
    /opt/tak3-node/jre/bin/java -version 2>&1 | head -1 | sed 's/^/   /'
else
    say "Java 21" "the runtime, installed from the distribution packages if it is missing"
    if java -version 2>&1 | grep -q '"21'; then
        ok "already installed"
    else
        # A single broken third-party mirror makes apt-get update exit non-zero
        # even when every index we need was fetched; the install is what counts.
        apt-get update -qq || warn "apt-get update reported errors (broken mirror?) — continuing"
        apt-get install -y -qq openjdk-21-jdk jq curl || die "could not install openjdk-21-jdk"
        java -version 2>&1 | head -1
    fi
fi
for tool in curl jq unzip openssl; do
    command -v "$tool" >/dev/null 2>&1 || apt-get install -y -qq "$tool" >/dev/null || warn "could not install $tool"
done

# Pairing a node that is set up already gives it a new full-control key (only a
# digest of the old one is kept, and pairing sends the key itself), and the
# console holding the old one loses the node. On lcab a pairing meant for a
# second node, with MediaMTX, ran on its Nimble node and cut the console off it.
# So it is asked, before anything changes, and refused when nobody can answer.
if [ -n "$PAIR" ] && [ -n "$PREV_SRC" ] && [ -n "$(prev web.authentication.apikey)" ] && [ "$NEW_KEYS" != yes ]; then
    warn "this node is set up already, and a console may hold its full-control key"
    hint "pairing gives it a new key: a console holding the old one loses this node until it has the new one"
    if [ "$(prev media.server)" = nimble ] && [ -z "$INSTANCE" ]; then
        hint "to add MediaMTX beside Nimble instead, as a second node on this machine:"
        hint "    sudo tak3-node-setup --instance mtx --pair $PAIR"
    fi
    yesno REPAIR "Pair this node itself again, with a new key?" n
    [ "$REPAIR" = y ] || die "nothing was changed. A second node beside this one: sudo tak3-node-setup --instance <name> --pair <address>"
fi

# --- 3. the media server ----------------------------------------------------
say "The media server" "which one runs here, and proof that the node can reach it"
if [ -z "$MEDIA" ]; then
    MEDIA=$(prev media.server)
fi
if [ -n "$INSTANCE" ]; then
    # One Nimble per machine, and it has the main node already.
    MEDIA=${MEDIA:-mediamtx}
    if [ "$MEDIA" = nimble ] && grep -qx 'media.server=nimble' /etc/tak3-node/application.properties 2>/dev/null; then
        die "Nimble here already has its node (tak3-node). A named node is for MediaMTX beside it: MEDIA=mediamtx"
    fi
fi
# One MediaMTX per machine, and one node for it.
if [ "$MEDIA" = mediamtx ]; then
    for other in /etc/tak3-node/application.properties /etc/tak3-node/instances/*.properties; do
        [ -f "$other" ] && [ "$other" != "$CONFIG" ] || continue
        grep -qx 'media.server=mediamtx' "$other" \
            && die "MediaMTX here already has its node ($other) — set that one up again instead"
    done
fi
if [ -z "$MEDIA" ]; then
    if [ -f "$NIMBLE_CONF" ] && [ "$PREV_SRC" = unit ]; then
        MEDIA=nimble        # a script install from before MediaMTX was an option
    elif [ -f "$NIMBLE_CONF" ]; then
        read -r -p "   Nimble is installed here. Use it (n = MediaMTX instead)? (Y/n): " A </dev/tty || A=y
        [ "${A:-y}" = n ] && MEDIA=mediamtx || MEDIA=nimble
    else
        MEDIA=mediamtx
    fi
fi
case "$MEDIA" in mediamtx|nimble) ;; *) die "MEDIA must be mediamtx or nimble, not '$MEDIA'" ;; esac
ok "$MEDIA"

# MediaMTX: one binary, one configuration file, one service. The release is
# fetched from its own project and checked against the checksum that project
# publishes; its licence (MIT) goes beside it.
install_mediamtx() {
    local arch tmp base expected actual
    arch=$(dpkg --print-architecture)
    case "$arch" in amd64|arm64) ;; *) die "no MediaMTX build for $arch here — install it by hand, then re-run" ;; esac
    tmp=$(mktemp -d)
    base=https://github.com/bluenviron/mediamtx/releases/download/$MEDIAMTX_VERSION
    curl -fsSL -o "$tmp/mediamtx.tar.gz" "$base/mediamtx_${MEDIAMTX_VERSION}_linux_${arch}.tar.gz" \
        || die "could not download MediaMTX $MEDIAMTX_VERSION — check the network"
    # The tested release is checked against checksums kept here, so a
    # download and its checksum list replaced together are still caught. Any
    # other version can only be checked against what its release publishes.
    case "${MEDIAMTX_VERSION}_${arch}" in
        v1.21.2_amd64) expected=121be6e00397e473a95d83c75f4fcd3819a6af3b0e1a50889cba43ab4fab6a27 ;;
        v1.21.2_arm64) expected=180a235374a548d9133cdd5e20f5dbd8b01317be1c86e0d7e66df585dc42ed6f ;;
        v1.21.1_amd64) expected=653abc672a3e693f8d3b2717752492fdcfb8072291ec108d03d3dd857411b0ee ;;
        v1.21.1_arm64) expected=6a3aa635fb60ea9b8d566ec306f0a42ff1b6b52a3942bc2baffbe55880d4c3dd ;;
        *)
            curl -fsSL -o "$tmp/checksums.sha256" "$base/checksums.sha256" || die "could not download MediaMTX's checksums"
            expected=$(grep "mediamtx_${MEDIAMTX_VERSION}_linux_${arch}.tar.gz\$" "$tmp/checksums.sha256" | awk '{print $1}')
            ;;
    esac
    actual=$(sha256sum "$tmp/mediamtx.tar.gz" | awk '{print $1}')
    [ -n "$expected" ] && [ "$expected" = "$actual" ] || die "MediaMTX download does not match its published checksum — not installed"
    ok "MediaMTX $MEDIAMTX_VERSION downloaded, checksum matches"
    tar -xzf "$tmp/mediamtx.tar.gz" -C "$tmp"
    getent passwd mediamtx >/dev/null || adduser --system --group --home /var/lib/mediamtx --no-create-home \
        --shell /usr/sbin/nologin mediamtx >/dev/null
    install -d -o mediamtx -g mediamtx /var/lib/mediamtx
    install -d /opt/mediamtx /etc/mediamtx
    install -m 755 "$tmp/mediamtx" /opt/mediamtx/mediamtx
    [ -f "$tmp/LICENSE" ] && install -m 644 "$tmp/LICENSE" /opt/mediamtx/LICENSE
    if [ -f /etc/mediamtx/mediamtx.yml ]; then
        ok "keeping /etc/mediamtx/mediamtx.yml"
    else
        # The shipped defaults, with the three services the node reads switched
        # on and kept to this machine: the API, the metrics and the recordings.
        # Media over QUIC (8892, 8893/udp) is switched off rather than left on
        # every address: nothing here, the console or a player it hands out,
        # uses it. RTSP keeps its UDP transport (8000, 8001/udp): players such
        # as ffmpeg ask for UDP first and are refused rather than moved to TCP.
        # The administrator is this node, by name and password (stored hashed),
        # instead of anyone on loopback: a container on the host's network is on
        # loopback too.
        local hash moved=""
        hash=$(printf '%s' "$MTX_PASS" | openssl dgst -sha256 -binary | base64)
        # Ports another server here already uses — Nimble's 1935, most often —
        # move to the next free one, so the two run side by side.
        local -a portsed=()
        local key proto def got
        for spec in rtmpAddress:t:1935 rtmpsAddress:t:1936 rtspAddress:t:8554 rtspsAddress:t:8322 rtpAddress:u:8000 \
                    rtcpAddress:u:8001 srtpAddress:u:8004 srtcpAddress:u:8005 hlsAddress:t:8888 webrtcAddress:t:8889 \
                    webrtcLocalUDPAddress:u:8189 srtAddress:u:8890 moqQUICAddress:u:8893 pprofAddress:t:9999; do
            IFS=: read -r key proto def <<< "$spec"
            first_free got "$proto" "$def"
            if [ "$got" != "$def" ]; then
                portsed+=(-e "s/^$key: :$def\$/$key: :$got/")
                moved="$moved $key=$got"
            fi
        done
        sed -e 's/^api: false/api: true/' -e 's/^apiAddress: :9997/apiAddress: 127.0.0.1:9997/' \
            -e 's/^metrics: false/metrics: true/' -e 's/^metricsAddress: :9998/metricsAddress: 127.0.0.1:9998/' \
            -e 's/^playback: false/playback: true/' -e 's/^playbackAddress: :9996/playbackAddress: 127.0.0.1:9996/' \
            -e 's/^moq: true/moq: false/' \
            "${portsed[@]+"${portsed[@]}"}" \
            "$tmp/mediamtx.yml" | awk -v user="$MTX_USER" -v hash="$hash" '
                # Anyone may watch, nobody may publish without a password:
                # the anonymous user keeps read and playback, not publish.
                /# Default unprivileged user\./ { unpriv=1 }
                unpriv && /# Default administrator\./ { unpriv=0; skip=0 }
                unpriv && /^      - action: publish$/ { skip=1; next }
                skip && /^      - action: / { skip=0 }
                skip { next }
                /# Default administrator\./ { admin=1 }
                admin && /^  - user: any$/ { print "  - user: " user; next }
                admin && /^    pass:$/ { print "    pass: sha256:" hash; next }
                admin && /^    ips: / { print "    ips: [\"127.0.0.1\", \"::1\", \"172.16.0.0/12\"]"; admin=0; next }
                { print }' > /etc/mediamtx/mediamtx.yml
        grep -q "^  - user: $MTX_USER\$" /etc/mediamtx/mediamtx.yml \
            || die "MediaMTX's configuration did not take this node's credentials — its layout has changed; install it by hand"
        awk '/# Default unprivileged user\./{u=1} /# Default administrator\./{u=0} u && /action: publish/{bad=1} END{exit bad}' \
            /etc/mediamtx/mediamtx.yml || die "MediaMTX's configuration still lets anyone publish — its layout has changed; install it by hand"
        chown root:mediamtx /etc/mediamtx/mediamtx.yml
        chmod 640 /etc/mediamtx/mediamtx.yml
        ok "wrote /etc/mediamtx/mediamtx.yml (API, metrics and playback on 127.0.0.1, for this node only)"
        grep -q '^moq: false' /etc/mediamtx/mediamtx.yml \
            && ok "Media over QUIC switched off: nothing uses it, so it does not listen" \
            || warn "MediaMTX's layout has changed: Media over QUIC may still listen on 8892 and 8893; see /etc/mediamtx/mediamtx.yml"
        [ -z "$moved" ] || ok "ports in use here were moved:${moved}"
    fi
    rm -rf "$tmp"
    cat > /etc/systemd/system/mediamtx.service <<'MTXUNIT'
[Unit]
Description=MediaMTX media server
After=network-online.target
Wants=network-online.target

[Service]
User=mediamtx
Group=mediamtx
ExecStart=/opt/mediamtx/mediamtx /etc/mediamtx/mediamtx.yml
WorkingDirectory=/var/lib/mediamtx
Restart=on-failure
RestartSec=3
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
MTXUNIT
    systemctl daemon-reload
    systemctl enable --now mediamtx.service >/dev/null 2>&1 || true
    systemctl restart mediamtx.service
}
# The node's own name and password for MediaMTX's API, metrics and profiler,
# kept on a re-run. A MediaMTX that still lets anyone on loopback in accepts
# them too, so they are always sent.
MTX_USER=$(prev media.mediamtx.user)
MTX_USER=${MTX_USER:-tak3-node}
MTX_PASS=$(prev media.mediamtx.password)
if is_sealed "$MTX_PASS"; then
    MTX_PASS=$(unseal "$MTX_PASS") || die "the MediaMTX password in the settings does not open with $SECRET_KEY — was it replaced?"
fi
MTX_PASS=${MTX_PASS:-$(openssl rand -hex 24)}
mtx_up() { curl -sf --max-time 3 -u "$MTX_USER:$MTX_PASS" "$MTX_API/v3/info" >/dev/null 2>&1; }

# A MediaMTX that refuses this node's password while its configuration names
# this node: setup wrote that entry, and the password went unrecorded (a run
# that stopped half way, or node settings that were lost). The entry is ours,
# so it gets the password on record now.
repair_mtx_password() {
    local yml=/etc/mediamtx/mediamtx.yml hash code
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 -u "$MTX_USER:$MTX_PASS" "$MTX_API/v3/info" || true)
    [ "$code" = 401 ] && [ -f "$yml" ] && grep -q "^  - user: $MTX_USER\$" "$yml" \
        && [ -f /etc/systemd/system/mediamtx.service ] || return 1
    warn "MediaMTX refuses this node's password, which was never recorded; setting a new one (MediaMTX restarts)"
    hash=$(printf '%s' "$MTX_PASS" | openssl dgst -sha256 -binary | base64)
    cp -p "$yml" "/root/mediamtx.yml.$(date +%s)"
    awk -v user="$MTX_USER" -v hash="$hash" '
        $0 == "  - user: " user { mine=1; print; next }
        mine && /^    pass:/ { print "    pass: sha256:" hash; mine=0; next }
        { print }' "$yml" > "$yml.new"
    chown root:mediamtx "$yml.new"
    chmod 640 "$yml.new"
    mv "$yml.new" "$yml"
    systemctl restart mediamtx.service
    for _ in $(seq 1 20); do mtx_up && return 0; sleep 1; done
    return 1
}

# MediaMTX's log in a file as well as the journal, for the console's Log tab:
# a folder MediaMTX writes and the node's group may read, nobody else, and a
# week of it kept by logrotate (copied and truncated in place, as MediaMTX
# keeps the file open). journalctl -u mediamtx keeps working as before.
set_mediamtx_log() {
    local yml=/etc/mediamtx/mediamtx.yml dir=/var/log/mediamtx want_dest='[stdout, file]' want_file=/var/log/mediamtx/mediamtx.log k v cur changed=""
    [ -f "$yml" ] || return 0
    install -d -m 750 -o mediamtx -g "$SERVICE_USER" "$dir"
    cat > /etc/logrotate.d/mediamtx <<'ROTATE'
/var/log/mediamtx/mediamtx.log {
    daily
    rotate 7
    maxsize 50M
    missingok
    notifempty
    compress
    delaycompress
    copytruncate
}
ROTATE
    for k in logDestinations logFile; do
        v=$([ "$k" = logDestinations ] && echo "$want_dest" || echo "$want_file")
        cur=$(grep -m1 "^$k:" "$yml" | sed -E "s/^$k: *//" || true)
        [ "$cur" = "$v" ] || changed=yes
    done
    if [ -z "$changed" ]; then
        ok "MediaMTX logs to $want_file too, for the console"
        return 0
    fi
    cp -p "$yml" "/root/mediamtx.yml.$(date +%s)"
    cp -p "$yml" "$yml.new"
    for k in logDestinations logFile; do
        v=$([ "$k" = logDestinations ] && echo "$want_dest" || echo "$want_file")
        if grep -q "^$k:" "$yml.new"; then
            awk -v k="$k" -v v="$v" 'index($0, k ":") == 1 && !done { print k ": " v; done=1; next } { print }' "$yml.new" > "$yml.tmp" && mv "$yml.tmp" "$yml.new"
        else
            printf '%s: %s\n' "$k" "$v" >> "$yml.new"
        fi
    done
    chown root:mediamtx "$yml.new"
    chmod 640 "$yml.new"
    mv "$yml.new" "$yml"
    if curl -sf -o /dev/null --max-time 5 -u "$MTX_USER:$MTX_PASS" -X PATCH -H 'Content-Type: application/json' \
            -d "{\"logDestinations\":[\"stdout\",\"file\"],\"logFile\":\"$want_file\"}" "$MTX_API/v3/config/global/patch"; then
        ok "MediaMTX logs to $want_file too, for the console (a week kept)"
    else
        warn "MediaMTX did not take its log file while running: it writes it from its next restart"
    fi
}

# MediaMTX's SSL settings in its own configuration, and applied while it runs:
# RTMPS beside RTMP (plain RTMP keeps working), HTTPS for HLS and WebRTC.
# Each key is replaced where it is, or added; the old file is kept in /root.
set_mediamtx_tls() {
    local dir=$1 want=$2 yml=/etc/mediamtx/mediamtx.yml k v cur changed="" patch
    [ -f "$yml" ] || { [ "$want" = off ] || warn "no $yml: MediaMTX's SSL is set in its own configuration here"; return 0; }
    local -a keys vals
    if [ "$want" = on ]; then
        keys=(rtmpEncryption rtmpServerKey rtmpServerCert hlsEncryption hlsServerKey hlsServerCert webrtcEncryption webrtcServerKey webrtcServerCert)
        vals=('"optional"' "$dir/privkey.pem" "$dir/fullchain.pem" yes "$dir/privkey.pem" "$dir/fullchain.pem" yes "$dir/privkey.pem" "$dir/fullchain.pem")
    else
        keys=(rtmpEncryption hlsEncryption webrtcEncryption)
        vals=('"no"' no no)
    fi
    for i in "${!keys[@]}"; do
        cur=$(grep -m1 "^${keys[$i]}:" "$yml" | sed -E "s/^${keys[$i]}: *//" || true)
        [ "$cur" = "${vals[$i]}" ] || changed=yes
    done
    if [ -z "$changed" ]; then
        [ "$want" = off ] || ok "MediaMTX is on SSL already: RTMPS, and HTTPS for HLS and WebRTC"
        return 0
    fi
    [ "$want" = on ] || grep -q '^rtmpEncryption: *"\{0,1\}\(optional\|strict\)' "$yml" || grep -q '^hlsEncryption: *yes' "$yml" || return 0
    cp -p "$yml" "/root/mediamtx.yml.$(date +%s)"
    cp -p "$yml" "$yml.new"
    for i in "${!keys[@]}"; do
        k=${keys[$i]}; v=${vals[$i]}
        if grep -q "^$k:" "$yml.new"; then
            awk -v k="$k" -v v="$v" 'index($0, k ":") == 1 && !done { print k ": " v; done=1; next } { print }' "$yml.new" > "$yml.tmp" && mv "$yml.tmp" "$yml.new"
        else
            printf '%s: %s\n' "$k" "$v" >> "$yml.new"
        fi
    done
    chown root:mediamtx "$yml.new"
    chmod 640 "$yml.new"
    mv "$yml.new" "$yml"
    if [ "$want" = on ]; then
        patch=$(jq -cn --arg k "$dir/privkey.pem" --arg c "$dir/fullchain.pem" '{rtmpEncryption:"optional", rtmpServerKey:$k, rtmpServerCert:$c,
            hlsEncryption:true, hlsServerKey:$k, hlsServerCert:$c, webrtcEncryption:true, webrtcServerKey:$k, webrtcServerCert:$c}')
    else
        patch='{"rtmpEncryption":"no","hlsEncryption":false,"webrtcEncryption":false}'
    fi
    if curl -sf -o /dev/null --max-time 10 -u "$MTX_USER:$MTX_PASS" -X PATCH -H 'Content-Type: application/json' \
            -d "$patch" "$MTX_API/v3/config/global/patch"; then
        if [ "$want" = on ]; then
            ok "MediaMTX on SSL: RTMPS on port $(mtx_port rtmpsAddress 1936) beside RTMP, HTTPS for HLS and WebRTC (their viewers reconnected once)"
        else
            ok "MediaMTX without SSL: RTMP, HLS and WebRTC are plain again"
        fi
    else
        warn "MediaMTX did not take its SSL settings while running: they apply from its next restart"
        hint "now, with streams and viewers reconnecting:  sudo systemctl restart mediamtx"
    fi
}

# Where MediaMTX writes its recordings: its recordPath, root's to change here
# and never the API's, which anyone holding the node's key can reach. The part
# of the template that names each file stays as it is, so the recordings made
# so far are still found once they are moved along.
set_record_folder() {
    local f=${1%/} yml=/etc/mediamtx/mediamtx.yml cur base tail new old wd size moved=0 left=0 file rel
    [[ $f == /?* ]] || die "--record-folder takes a full path, like /srv/recordings"
    case "$f" in
        /etc|/etc/*|/root|/root/*|/proc*|/sys*|/dev*|/boot*|/run*|/var/run*|/usr*|/opt*|/bin*|/sbin*|/lib*|/var/lib/tak3-node*)
            die "$f is a system folder: recordings are never written there" ;;
    esac
    [ -f "$yml" ] || die "no $yml: this MediaMTX keeps its configuration elsewhere; set recordPath there"
    cur=$(curl -sf --max-time 3 -u "$MTX_USER:$MTX_PASS" "$MTX_API/v3/config/pathdefaults/get" | jq -r '.recordPath // empty' || true)
    [ -n "$cur" ] || cur=$(awk '/^pathDefaults:/{p=1;next} p&&/^[^ #]/{p=0} p&&/^  recordPath:/{sub(/^  recordPath: */,"");print;exit}' "$yml")
    [ -n "$cur" ] || cur='./recordings/%path/%Y-%m-%d_%H-%M-%S-%f'
    base=${cur%%\%*}; base=${base%/*}
    tail=${cur#"$base"}
    case "$tail" in /*%*) ;; *) tail="/%path/%Y-%m-%d_%H-%M-%S-%f" ;; esac
    new="$f$tail"
    wd=$(systemctl show -p WorkingDirectory --value mediamtx.service 2>/dev/null || true)
    old=$base; [[ $old == /* ]] || old="${wd:-/var/lib/mediamtx}/${old#./}"
    old=$(realpath -m "$old")

    if [ ! -d "$f" ]; then
        install -d -o mediamtx -g mediamtx -m 755 "$f"
        ok "made $f for recordings"
    fi
    if ! runuser -u mediamtx -- test -w "$f" -a -x "$f"; then
        chgrp mediamtx "$f" && chmod g+rwx "$f"
        ok "opened $f to MediaMTX: its group, mediamtx, may write there"
    fi
    runuser -u mediamtx -- test -w "$f" -a -x "$f" \
        || die "MediaMTX still cannot write $f: a folder above it is closed to the mediamtx user"

    if [ "$(realpath -m "$f")" = "$old" ] && [ "$new" = "$cur" ]; then
        ok "MediaMTX records into $f already"
        return 0
    fi
    cp -p "$yml" "/root/mediamtx.yml.$(date +%s)"
    awk -v p="$new" '
        /^pathDefaults:/ { pd=1; print; next }
        pd && /^[^ #]/ { if (!done) { print "  recordPath: " p; done=1 } pd=0 }
        pd && /^  recordPath:/ { print "  recordPath: " p; done=1; next }
        { print }
        END { if (pd && !done) print "  recordPath: " p }' "$yml" > "$yml.new"
    grep -q "^  recordPath: $new\$" "$yml.new" || die "could not set recordPath in $yml: its layout has changed; set it by hand"
    chown root:mediamtx "$yml.new"
    chmod 640 "$yml.new"
    mv "$yml.new" "$yml"
    ok "set in $yml: recordPath: $new (the old one is in /root/mediamtx.yml.*)"
    if curl -sf -o /dev/null --max-time 5 -u "$MTX_USER:$MTX_PASS" -X PATCH -H 'Content-Type: application/json' \
            -d "$(jq -cn --arg p "$new" '{recordPath: $p}')" "$MTX_API/v3/config/pathdefaults/patch"; then
        ok "MediaMTX records into $f from now on, without a restart"
    else
        warn "MediaMTX did not take it while running: it records into $f from its next restart"
        hint "now, with live streams reconnecting:  sudo systemctl restart mediamtx"
    fi

    if [ -d "$old" ] && [ -n "$(find "$old" -type f -print -quit 2>/dev/null)" ]; then
        size=$(du -sh "$old" 2>/dev/null | cut -f1)
        yesno MOVE_RECORDINGS "Move the recordings made so far (${size:-?} in $old) to $f? Left there, they drop out of the timeline and cannot be archived" y
        if [ "$MOVE_RECORDINGS" = y ]; then
            # Not the newest: a segment may still be being written there.
            sleep 2
            while IFS= read -r -d '' file; do
                rel=${file#"$old"/}
                runuser -u mediamtx -- mkdir -p "$f/$(dirname "$rel")"
                if mv -n "$file" "$f/$rel" 2>/dev/null; then moved=$((moved + 1)); fi
            done < <(find "$old" -type f -mmin +2 -print0)
            find "$old" -mindepth 1 -type d -empty -delete 2>/dev/null || true
            left=$(find "$old" -type f 2>/dev/null | wc -l)
            ok "moved $moved recordings to $f"
            [ "$left" -eq 0 ] || hint "$left written in the last minutes stay in $old: the same command moves them later"
        else
            hint "they stay in $old; the same command moves them later"
        fi
    fi
}

if [ "$MEDIA" = mediamtx ]; then
    if mtx_up || repair_mtx_password; then
        ok "MediaMTX $(curl -sf --max-time 3 -u "$MTX_USER:$MTX_PASS" "$MTX_API/v3/info" | jq -r '.version // "?"') answers on 127.0.0.1:9997"
        if grep -A3 'Default administrator' /etc/mediamtx/mediamtx.yml 2>/dev/null | grep -q '^  - user: any$'; then
            hint "its configuration still lets anyone on this machine use the API until the node takes over;"
            hint "to close that too, give the 'Default administrator' entry in /etc/mediamtx/mediamtx.yml"
            hint "  user: $MTX_USER   and   pass: sha256:\$(printf '%s' '<the password in the node settings>' | openssl dgst -sha256 -binary | base64)"
        fi
    elif [ -f /etc/mediamtx/mediamtx.yml ] || [ -f /usr/local/etc/mediamtx.yml ]; then
        warn "MediaMTX is installed but its API does not answer on 127.0.0.1:9997"
        hint "the node needs these in its mediamtx.yml, then a restart of MediaMTX:"
        hint "  api: true      apiAddress: 127.0.0.1:9997"
        hint "  metrics: true  metricsAddress: 127.0.0.1:9998"
        hint "  playback: true playbackAddress: 127.0.0.1:9996"
        die "switch those on, restart MediaMTX, then re-run: sudo $ME"
    else
        yesno INSTALL_MTX "MediaMTX is not installed. Install MediaMTX $MEDIAMTX_VERSION now?" y
        [ "$INSTALL_MTX" = y ] || die "the node needs MediaMTX on this machine — install it, then re-run: sudo $ME"
        install_mediamtx
        for _ in $(seq 1 20); do mtx_up && break; sleep 1; done
        mtx_up || die "MediaMTX did not start — journalctl -u mediamtx -n 30"
        ok "MediaMTX running as a service (mediamtx.service)"
    fi
    curl -sf -o /dev/null --max-time 3 -u "$MTX_USER:$MTX_PASS" http://127.0.0.1:9998/metrics \
        && ok "metrics answer on 127.0.0.1:9998" \
        || warn "MediaMTX metrics do not answer on 127.0.0.1:9998 — viewer and byte counts will be missing"
    PB=$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 "http://127.0.0.1:9996/list?path=tak3-check" || true)
    case "$PB" in 000|"") warn "MediaMTX playback does not answer on 127.0.0.1:9996 — recordings cannot be listed or archived" ;;
                  *) ok "playback answers on 127.0.0.1:9996" ;; esac
    [ -z "$RECORD_FOLDER" ] || set_record_folder "$RECORD_FOLDER"
    # Where MediaMTX actually listens, from MediaMTX: transcoders read from and
    # publish to its RTMP port, copies read its RTSP port, and beside Nimble
    # those are not the usual ones.
    MTX_GLOBAL=$(curl -sf --max-time 3 -u "$MTX_USER:$MTX_PASS" "$MTX_API/v3/config/global/get" || true)
    mtx_port() {
        local v
        v=$(printf '%s' "$MTX_GLOBAL" | jq -r --arg k "$1" '.[$k] // empty' 2>/dev/null || true)
        v=${v##*:}
        printf '%s' "${v:-$2}"
    }
    RTMP_PORT=$(mtx_port rtmpAddress 1935)
    RTSP_PORT=$(mtx_port rtspAddress 8554)
    HLS_PORT=$(mtx_port hlsAddress 8888)
    WEBRTC_PORT=$(mtx_port webrtcAddress 8889)
    # WebRTC's picture and sound travel on a port of their own: its page on
    # WEBRTC_PORT opens nothing for them, so a firewall needs this one too.
    WEBRTC_UDP_PORT=$(mtx_port webrtcLocalUDPAddress 8189)
    SRT_PORT=$(mtx_port srtAddress 8890)
    [ "$RTMP_PORT" = 1935 ] || ok "MediaMTX takes RTMP on $RTMP_PORT; transcoders here read and publish there"
else
    [ -f "$NIMBLE_CONF" ] || die "$NIMBLE_CONF not found — is Nimble installed? (MEDIA=mediamtx for MediaMTX)"
    # Backups must never live in Nimble's --conf-dir: it reads the whole
    # directory, and a stale copy silently competes with the live config.
    find /etc/nimble -maxdepth 1 -name '*.bak' -o -maxdepth 1 -name '*.orig' 2>/dev/null | while read -r stray; do
        warn "moving $stray out of Nimble's config dir"
        mv "$stray" /root/
    done
    TOKEN_COUNT=$(grep -c '^\s*management_token' "$NIMBLE_CONF" || true)
    [ "$TOKEN_COUNT" -le 1 ] || die "$TOKEN_COUNT management_token lines in $NIMBLE_CONF — keep exactly one, then re-run"
    if [ "$TOKEN_COUNT" -eq 0 ]; then
        warn "no management_token set; adding one (Nimble restart required)"
        NEW_TOKEN=$(openssl rand -hex 16)
        cp "$NIMBLE_CONF" "/root/nimble.conf.bak.$(date +%s)"
        printf '\nmanagement_token = %s\nmanagement_listen_interfaces = 127.0.0.1\n' "$NEW_TOKEN" >> "$NIMBLE_CONF"
        warn "restarting Nimble — live streams on this server will drop briefly"
        service nimble restart
        sleep 3
    fi
    grep -q '^\s*management_listen_interfaces' "$NIMBLE_CONF" || \
        warn "management_listen_interfaces is not set — Nimble accepts no API requests until it is"
    TOKEN=$(grep -oP '^\s*management_token\s*=\s*\K\S+' "$NIMBLE_CONF" | head -1 || true)
    [ -n "$TOKEN" ] || die "could not read management_token"
    ok "management token present (${#TOKEN} chars)"
    # Nimble honours the LAST occurrence of a setting, so read the same one it did.
    LISTEN_COUNT=$(grep -c '^\s*management_listen_interfaces' "$NIMBLE_CONF" || true)
    [ "$LISTEN_COUNT" -le 1 ] || \
        warn "$LISTEN_COUNT management_listen_interfaces lines — Nimble uses the last; consider removing the others"
    MGMT_PORT=$(grep -oP '^\s*management_port\s*=\s*\K[0-9]+' "$NIMBLE_CONF" | tail -1 || true)
    MGMT="http://127.0.0.1:${MGMT_PORT:-8082}"
    # The hash is sent to Nimble verbatim — never URL-encoded. Restricting it to
    # [A-Za-z0-9=] avoids '+' (read as a space in a query string) and '/'.
    SALT=""; HASH=""
    for _ in $(seq 1 50); do
        S=$(( RANDOM % 1000000 ))
        H=$(printf '%s' "$S/$TOKEN" | openssl md5 -binary | base64)
        case "$H" in *+*|*/*) continue;; esac
        CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$MGMT/manage/server_status?salt=$S&hash=$H" || true)
        if [ "$CODE" = "200" ]; then SALT=$S; HASH=$H; break; fi
        # a wrong token fails for every salt, so stop rather than spin
        [ "$CODE" = "403" ] && die "Nimble rejected the credentials (HTTP 403).
   The running Nimble is using a different token than $NIMBLE_CONF.
   Restart Nimble so it reloads the config, then re-run."
        [ -z "$CODE" ] || [ "$CODE" = "000" ] && die "cannot reach $MGMT — is the management API enabled?"
    done
    [ -n "$SALT" ] || die "could not generate a working salt/hash pair"
    ok "salt/hash verified against Nimble's API at $MGMT (HTTP 200)"
fi

# --- 4. docker, for transcoding ---------------------------------------------
# A ladder is one ffmpeg container per input stream; the node starts and
# stops them itself. Without Docker the node still runs — every transcoder
# then just reports "docker unavailable".
say "Docker (transcoding)" "only needed on a box that will run transcoder ladders; answer n and nothing Docker-related is installed"
TRANSCODE=${TRANSCODE:-}
if [ -z "$TRANSCODE" ] && [ -n "$(prev transcoderEnabled)" ]; then
    [ "$(prev transcoderEnabled)" = true ] && TRANSCODE=yes || TRANSCODE=no
fi
if [ -z "$TRANSCODE" ]; then
    read -r -p "   Will this server run transcoders? Needs Docker (Y/n): " ANSWER </dev/tty || ANSWER=y
    [ "${ANSWER:-y}" = "n" ] && TRANSCODE=no || TRANSCODE=yes
fi
if [ "$TRANSCODE" = "yes" ]; then
    if ! command -v docker >/dev/null 2>&1; then
        apt-get update -qq || warn "apt-get update reported errors — continuing"
        apt-get install -y -qq docker.io || die "could not install docker.io
   Install Docker by hand (https://docs.docker.com/engine/install/), then re-run."
    fi
    systemctl enable --now docker >/dev/null 2>&1 || true
    docker info >/dev/null 2>&1 || die "docker is installed but its daemon is not answering — systemctl status docker"
    ok "docker $(docker version --format '{{.Server.Version}}' 2>/dev/null || echo '?')"
    # The ffmpeg image is built here rather than pulled from a public tag.
    # Which flags an ffmpeg was configured with decides what may be done with
    # the binary, and a tag on a public registry can be moved under you between
    # installs. This base is pinned by digest, so a rebuild in a year starts
    # from the same bytes as today, and the build refuses a non-free ffmpeg —
    # those may not be passed on by anyone. Nothing here is published: the
    # image is built on this server, for this server.
    if docker image inspect "$IMAGE" >/dev/null 2>&1; then
        ok "image $IMAGE present"
    elif [ "$IMAGE" != "$DEFAULT_IMAGE" ]; then
        # An image the operator named themselves: theirs to provide.
        docker pull -q "$IMAGE" >/dev/null || die "could not pull $IMAGE — check the tag or the network"
        ok "pulled $IMAGE"
    else
        BUILD_DIR=$(mktemp -d)
        cat > "$BUILD_DIR/Dockerfile" <<'DOCKERFILE'
# Alpine's own ffmpeg: built with --enable-gpl (it carries x264 and x265) and
# without --enable-nonfree, which Alpine states as
# "GPL-2.0-or-later AND LGPL-2.1-or-later". No libfdk_aac: that encoder exists
# only in a non-free build, and such a binary may not be passed to anyone.
FROM alpine:3.22@sha256:5291449c3df73caf6ed85e649dec1b9e818b39a5d8c871e97afc13e9cd5e8fa8
RUN apk add --no-cache ffmpeg
RUN ffmpeg -version > /etc/tak3-ffmpeg-configuration.txt 2>&1 \
    && if grep -q -- '--enable-nonfree' /etc/tak3-ffmpeg-configuration.txt; then \
         echo 'REFUSED: non-free ffmpeg build' >&2; exit 1; fi \
    && ffmpeg -hide_banner -encoders 2>/dev/null | grep -qw libx264 \
    && ffmpeg -hide_banner -encoders 2>/dev/null | grep -qw aac
ENTRYPOINT ["ffmpeg"]
DOCKERFILE
        printf '       \033[2mbuilding %s — a minute or two the first time\033[0m\n' "$IMAGE"
        docker build -q -t "$IMAGE" "$BUILD_DIR" >/dev/null \
            || { rm -rf "$BUILD_DIR"; die "could not build $IMAGE — check the network and 'docker build' by hand"; }
        rm -rf "$BUILD_DIR"
        ok "built $IMAGE"
    fi
    # Captured whole, not piped into head: under pipefail, head closing the
    # pipe early ended this script on SIGPIPE, silently, now and then.
    FF_VERSION=$(docker run --rm --entrypoint ffmpeg "$IMAGE" -version 2>/dev/null || true)
    FF=${FF_VERSION%%$'\n'*}
    case "$FF" in
        ffmpeg*) ok "${FF% Copyright*} runs inside the image" ;;
        *) die "$IMAGE has no working ffmpeg on its path" ;;
    esac
    # Said out loud because it decides what may be done with the image, and it
    # is the first thing anyone asks when this product is resold.
    if [[ $FF_VERSION == *--enable-nonfree* ]]; then
        warn "this ffmpeg is a non-free build — it may be used here, but it may not be passed to anyone else"
    else
        ok "no non-free encoders in the image"
    fi
else
    warn "transcoding disabled on this server — no Docker needed"
fi

# The helper, and the one sudo rule that lets the service user run it.
install_docker_helper() {
    if [ -z "$PACKAGED" ]; then
        local src
        src="$(dirname "$0")/tak3-docker"
        [ -f "$src" ] || die "tak3-docker is missing beside this script — copy it from tools/ next to $(basename "$0"), then re-run"
        install -d -m 755 "$(dirname "$HELPER")"
        install -m 755 -o root -g root "$src" "$HELPER"
    fi
    [ -x "$HELPER" ] || die "$HELPER is missing — reinstall the package: sudo apt install --reinstall tak3-node"
    command -v sudo >/dev/null 2>&1 || apt-get install -y -qq sudo >/dev/null || die "could not install sudo, which runs the helper"
    {
        echo "# tak3-node runs containers only through this helper, which checks every command it is given."
        echo "Defaults:$SERVICE_USER !requiretty"
        echo "$SERVICE_USER ALL=(root) NOPASSWD: $HELPER"
    } > "$SUDOERS.new"
    chmod 440 "$SUDOERS.new"
    visudo -cqf "$SUDOERS.new" || { rm -f "$SUDOERS.new"; die "the sudo rule for $HELPER did not validate"; }
    mv "$SUDOERS.new" "$SUDOERS"
    ok "$SERVICE_USER runs containers through $HELPER: one sudo rule, no docker group"
}

# --- 5. user and directories ------------------------------------------------
say "Service user and directories" "an unprivileged user that owns its own directory and nothing else"
# A system account with no shell: it runs a service, nobody logs in as it.
id "$SERVICE_USER" >/dev/null 2>&1 || adduser --system --group --home "$INSTALL_DIR" --no-create-home \
    --shell /usr/sbin/nologin "$SERVICE_USER" >/dev/null
# MediaMTX's log, for the console: needs the node's group, made just above.
[ "$MEDIA" != mediamtx ] || ! mtx_up || set_mediamtx_log
# The group this fleet's export folders are shared through. The script install
# has always created it; the package only joins it where it already exists.
if [ -z "$PACKAGED" ]; then
    groupadd -f applicationsextern
    usermod -aG applicationsextern "$SERVICE_USER"
elif getent group applicationsextern >/dev/null; then
    usermod -aG applicationsextern "$SERVICE_USER"
fi
# Containers are run through a root-owned helper that accepts only the
# commands the node makes (tools/tak3-docker), never by membership of the
# docker group: that group is root, so a flaw in the node would have been a
# flaw in the whole machine.
if [ "$TRANSCODE" = "yes" ]; then
    install_docker_helper
else
    # The rule is the machine's, shared by every node on it: it goes only
    # when no other node here transcodes.
    OTHERS_TRANSCODE=""
    for other in /etc/tak3-node/application.properties /etc/tak3-node/instances/*.properties; do
        [ -f "$other" ] && [ "$other" != "$CONFIG" ] || continue
        grep -qx 'transcoderEnabled=true' "$other" && OTHERS_TRANSCODE=yes
    done
    [ -n "$OTHERS_TRANSCODE" ] || rm -f "$SUDOERS"
fi
if id -nG "$SERVICE_USER" 2>/dev/null | tr ' ' '\n' | grep -qx docker; then
    gpasswd -d "$SERVICE_USER" docker >/dev/null
    ok "$SERVICE_USER taken out of the docker group, which is the same as root"
fi
# The service's own folder, then everything inside it done as the service user
# (see as_service). A named node's folder sits under instances/, which is the
# service's already; the first node's under /var/lib, which is root's.
if [ -n "$INSTANCE" ]; then as_service mkdir -p "$INSTALL_DIR"; else mkdir -p "$INSTALL_DIR"; fi
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"   # -R never follows a link
as_service mkdir -p "$INSTALL_DIR/scripts" "$INSTALL_DIR/mp4"

# Nimble's DVR export runs a per-stream script, and without one the first
# export fails with "no archive.sh". The default ships inside the jar and is
# written here; an existing one is kept beside it. MediaMTX exports by itself.
install_archive_script() {
    local dir="$1" target="$1/archive.sh" previous="" fresh
    # Unpacked where only root writes, then handed to the service user on a
    # pipe: the scripts folder is the service's (see as_service).
    as_service mkdir -p "$dir"
    fresh=$(mktemp)
    if ! { unzip -p "$JAR" BOOT-INF/classes/archive.sh > "$fresh" 2>/dev/null && [ -s "$fresh" ]; }; then
        rm -f "$fresh"
        warn "no archive.sh in the jar — DVR export will not run until one is placed at $target"
        return
    fi
    if as_service sh -c '[ -e "$1" ] || [ -L "$1" ]' sh "$target"; then
        previous="$target.replaced-$(date +%s)"
        as_service mv -- "$target" "$previous"
    fi
    as_service sh -c 'umask 027; cat > "$1.new" && chmod 750 "$1.new" && mv -f -- "$1.new" "$1"' sh "$target" < "$fresh" \
        || { rm -f "$fresh"; die "$SERVICE_USER could not write $target — is $dir a link out of $INSTALL_DIR?"; }
    rm -f "$fresh"
    ok "wrote $target${previous:+ (previous kept at $(basename "$previous"))}"
    # A per-stream copy shadows this one, so replacing the shared script would
    # change nothing for those streams. Say which, rather than let the export
    # keep failing for reasons the operator cannot see.
    local shadowing
    shadowing=$(find "$dir" -mindepth 2 -name archive.sh 2>/dev/null || true)
    if [ -n "$shadowing" ]; then
        if [ "${REPLACE_STREAM_SCRIPTS:-no}" = "yes" ]; then
            local kept
            kept="$dir/.replaced-$(date +%s)"
            as_service mkdir -p "$kept"
            echo "$shadowing" | while read -r f; do
                [ -z "$f" ] || as_service mv -- "$f" "$kept/$(echo "${f#"$dir"/}" | tr / _)" </dev/null
            done
            ok "retired the per-stream archive.sh copies (kept in $kept)"
        else
            warn "these per-stream scripts shadow the shared one and are used instead:"
            echo "$shadowing" | sed 's/^/        /'
            warn "re-run with REPLACE_STREAM_SCRIPTS=yes to retire them"
        fi
    fi
}

if [ -z "$PACKAGED" ]; then
    # The unit runs a stable name; the versioned jar sits next to it. Updating
    # is then a symlink swap (update-node.sh), never an edit of the unit.
    if [ "$(readlink -f "$JAR")" != "$INSTALL_DIR/$JAR_NAME" ]; then
        place "$JAR" "$INSTALL_DIR/$JAR_NAME" "$SERVICE_USER" 0500
    fi
    ln -sfn "$INSTALL_DIR/$JAR_NAME" "$LINK"
fi
if [ "$MEDIA" = nimble ]; then install_archive_script "$INSTALL_DIR/scripts"; fi
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
if [ -z "$PACKAGED" ]; then
    # chmod follows a link: done by the service user, whose file this is.
    as_service chmod 500 "$INSTALL_DIR/$JAR_NAME"
fi
ok "$INSTALL_DIR ready"

# The key that seals the node's secrets, apart from the settings it protects:
# root's, readable by the service through its group, by no one else.
if [ ! -f "$SECRET_KEY" ]; then
    [ -d /etc/tak3-node ] || install -d -m 750 -o root -g "$SERVICE_USER" /etc/tak3-node
    (umask 077; openssl rand -hex 32 > "$SECRET_KEY.new")
    chown root:"$SERVICE_USER" "$SECRET_KEY.new"
    chmod 640 "$SECRET_KEY.new"
    mv "$SECRET_KEY.new" "$SECRET_KEY"
    ok "made $SECRET_KEY, which seals this node's secrets in its settings; back it up apart from them"
else
    chown root:"$SERVICE_USER" "$SECRET_KEY"
    chmod 640 "$SECRET_KEY"
fi

# --- 6. API keys: two of them ----------------------------------------------
# The full key changes things; the read-only key can only look. A console
# that must never touch this box gets the read-only one — then even a bug on
# the console cannot change anything here. Both survive a re-run: the
# consoles already hold them. The settings keep a digest of each, never the
# key: the node only compares, and a copy of the settings is then no way in.
# A key made here is shown once, at the end; one from before is not known here
# any more (the console holds it, and can change it: Servers › the server › Keys).
say "API keys" "one full-control and one read-only key for this node; existing keys are kept so the console keeps working"
API_DIGEST=$(prev web.authentication.apikey)
RO_DIGEST=$(prev readOnlyApiKey)
API_KEY=""; RO_KEY=""
# Rotated from the console since: a key in the settings may no longer be the one.
KEYS_FILE="$INSTALL_DIR/keys.json"
ROTATED=""; [ -f "$KEYS_FILE" ] && ROTATED=yes
if [ "$NEW_KEYS" = yes ]; then
    API_DIGEST=""; RO_DIGEST=""
    warn "new keys, as asked: every console holding the old ones must be given these, or pair this node again"
fi
# A key written out by an earlier version: kept, as its digest from now on.
if [ -n "$API_DIGEST" ] && ! is_digest "$API_DIGEST"; then
    [ -n "$ROTATED" ] || API_KEY=$API_DIGEST
    API_DIGEST=$(digest "$API_DIGEST")
    ok "the full-control key is kept as a digest from now on"
fi
if [ -n "$RO_DIGEST" ] && ! is_digest "$RO_DIGEST"; then
    [ -n "$ROTATED" ] || RO_KEY=$RO_DIGEST
    RO_DIGEST=$(digest "$RO_DIGEST")
fi
if [ -n "$API_DIGEST" ]; then ok "keeping the existing full-control key"; else API_KEY=$(newkey); API_DIGEST=$(digest "$API_KEY"); ok "new full-control key"; fi
if [ -n "$RO_DIGEST" ]; then ok "keeping the existing read-only key"; else RO_KEY=$(newkey); RO_DIGEST=$(digest "$RO_KEY"); ok "new read-only key"; fi
PAIR_OLD_DIGEST=""
if [ -n "$PAIR" ] && [ -z "$API_KEY" ]; then
    # Pairing sends the key itself, and only its digest is kept here. The old
    # one is remembered: a pairing that fails puts it back.
    PAIR_OLD_DIGEST=$API_DIGEST
    API_KEY=$(newkey); API_DIGEST=$(digest "$API_KEY")
    warn "a new full-control key, for pairing: the old one comes back if pairing fails"
fi
FORWARD=$(prev eventForwardUrl)
if [ -n "$FORWARD" ]; then
    # The console's address with the push key in it: sealed, like a password.
    if ! is_sealed "$FORWARD" && [[ $FORWARD == *key=* ]]; then
        FORWARD=$(seal "$FORWARD") || die "could not seal the event-forward setting with $SECRET_KEY"
    fi
    ok "keeping the event-forward setting"
fi
if [ -n "$CARRY" ]; then
    # Names only: some of these carry secrets.
    ok "keeping settings added by hand: $(printf '%s\n' "$CARRY" | sed '/^$/d; s/=.*//' | tr '\n' ' ')"
fi

# --- 7. port and configuration ----------------------------------------------
say "Port and configuration" "where the node listens, and the settings it starts with"
# Where the API answers. Never the internet unless asked for: the console
# reaches it over the tailnet, or on this machine.
LISTEN=${LISTEN:-$(prev server.address)}
TAILNET_IP=$(tailscale ip -4 2>/dev/null | head -n 1 || true)
if [ -z "$LISTEN" ]; then
    LISTEN=${TAILNET_IP:-127.0.0.1}
fi
[[ $LISTEN =~ ^[0-9.]+$ || $LISTEN =~ ^[0-9a-fA-F:]+$ ]] || die "--listen takes an address, such as 127.0.0.1, 100.101.102.103 or 0.0.0.0"
case "$LISTEN" in
    0.0.0.0|::) warn "the API answers on every address, the internet's included: firewall tcp $PORT to the console host" ;;
    127.*|::1) ok "the API answers on this machine only (127.0.0.1): for a console on this machine" ;;
    *) ok "the API answers on $LISTEN and 127.0.0.1, not on the internet" ;;
esac
if [ "$PREV_SRC" = props ] && [ -z "$(prev server.address)" ] && [ "$LISTEN" != 0.0.0.0 ]; then
    hint "it answered on every address before: a console that reached it at another address must now use"
    hint "http://$LISTEN:$PORT — or run setup again with --listen 0.0.0.0"
fi
# HTTPS beside it, with the node's own copy of a certificate: for a console
# across the internet, so the key never travels in the open.
NODE_TLS=/etc/tak3-node/tls
HTTPS_PORT=${HTTPS_PORT:-$(prev node.https.port)}
HTTPS_NAME=${HTTPS_NAME:-$(prev node.https.certificate)}
case "$HTTPS_PORT" in off|no|0) HTTPS_PORT="" ;; esac
if [ -n "$HTTPS_PORT" ]; then
    [[ $HTTPS_PORT =~ ^[0-9]+$ ]] && [ "$HTTPS_PORT" -ge 1024 ] && [ "$HTTPS_PORT" -le 65535 ] \
        || die "--https-port takes a port from 1024 to 65535: below that needs root, which the node is not"
    [ "$HTTPS_PORT" != "$PORT" ] || die "--https-port must differ from the API's port $PORT"
    if [ -z "$HTTPS_NAME" ]; then
        mapfile -t COPIES < <(find "$NODE_TLS" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null)
        [ ${#COPIES[@]} -eq 1 ] && HTTPS_NAME=${COPIES[0]}
    fi
    [ -n "$HTTPS_NAME" ] || die "which certificate? copy one first:  sudo $CERT_ME --certificate media.example.com
   then:  sudo $ME --https-port $HTTPS_PORT --https-name media.example.com"
    [ -f "$NODE_TLS/$HTTPS_NAME/fullchain.pem" ] && [ -f "$NODE_TLS/$HTTPS_NAME/privkey.pem" ] \
        || die "no copied certificate called $HTTPS_NAME: sudo $CERT_ME --certificate $HTTPS_NAME"
    if ss -ltn "sport = :$HTTPS_PORT" 2>/dev/null | grep -q LISTEN && [ "$(prev node.https.port)" != "$HTTPS_PORT" ]; then
        HOLDER=$(ss -ltnp "sport = :$HTTPS_PORT" 2>/dev/null | awk 'NR==2 {print $NF}' | sed -E 's/^users:\(\("([^"]+)".*/\1/')
        FREE_PORT=""
        for p in 9443 10443 18443 28443; do
            ss -ltn "sport = :$p" 2>/dev/null | grep -q LISTEN || { FREE_PORT=$p; break; }
        done
        die "port $HTTPS_PORT is already in use by ${HOLDER:-another program}.
   Choose a free port, one nothing else on this server uses${FREE_PORT:+ ($FREE_PORT is free here)}:  sudo $ME --https-port ${FREE_PORT:-<a free port>}"
    fi
    ok "HTTPS on port $HTTPS_PORT with the $HTTPS_NAME certificate, on every address"
fi
# On demand files over HTTPS on their own port: the default on a MediaMTX
# node. A website on https cannot play files from an http address, and a name
# that asks browsers for HTTPS (HSTS) gets https on every port, whatever the
# link says. Plain HTTP only when asked for (--vod-https off), or until there
# is a certificate for the name viewers use: setup offers to copy it here.
VOD_HTTPS_SAID=$VOD_HTTPS
VOD_HTTPS=${VOD_HTTPS:-$(prev vod.https)}
case "$VOD_HTTPS" in
    on|yes|true|1|"") VOD_HTTPS=true ;;
    off|no|false|0) VOD_HTTPS="" ;;
    *) die "--vod-https takes on or off" ;;
esac
if [ "$MEDIA" = nimble ]; then
    case "$VOD_HTTPS_SAID" in
        ""|off|no|false|0) ;;
        *) die "--vod-https is for a MediaMTX node. Nimble serves its own files: its HTTPS is set up in Nimble" ;;
    esac
    VOD_HTTPS=""
elif [ -n "$VOD_HTTPS" ]; then
    if [ -z "$HTTPS_NAME" ]; then
        mapfile -t COPIES < <(find "$NODE_TLS" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null)
        [ ${#COPIES[@]} -eq 1 ] && HTTPS_NAME=${COPIES[0]}
    fi
    if [ -z "$HTTPS_NAME" ]; then
        # None copied yet: copied now, for the name viewers use. Only when
        # someone is there to say which: a guess would serve another site's name.
        SUGGEST=""
        mapfile -t LIVE < <(find /etc/letsencrypt/live -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null)
        [ ${#LIVE[@]} -eq 1 ] && SUGGEST=${LIVE[0]}
        WANT=""
        if (: </dev/tty) 2>/dev/null \
                && read -r -p "   On demand files are served over HTTPS. The name viewers use for them${SUGGEST:+ [$SUGGEST]} (- for plain HTTP): " WANT </dev/tty; then
            WANT=${WANT:-$SUGGEST}
        else
            WANT=""
        fi
        case "$WANT" in
            ""|-|none) WANT="" ;;
            *) [[ $WANT =~ ^[A-Za-z0-9][A-Za-z0-9.-]{0,252}$ ]] || { warn "$WANT is not a name"; WANT=""; } ;;
        esac
        if [ -n "$WANT" ]; then
            if [ -n "$PACKAGED" ]; then CERT_JOB_RUN=(/usr/libexec/tak3-node/certificate); else CERT_JOB_RUN=(bash "$(dirname "$0")/certificate.sh"); fi
            if TAK3_FOR=node TAK3_QUIET=yes "${CERT_JOB_RUN[@]}" "$WANT"; then
                HTTPS_NAME=$WANT
            else
                warn "the certificate for $WANT could not be copied (the reason is above)"
            fi
        fi
    fi
    if [ -n "$HTTPS_NAME" ]; then
        [ -f "$NODE_TLS/$HTTPS_NAME/fullchain.pem" ] && [ -f "$NODE_TLS/$HTTPS_NAME/privkey.pem" ] \
            || die "no copied certificate called $HTTPS_NAME: sudo $CERT_ME --certificate $HTTPS_NAME"
        ok "On demand files over HTTPS on port $VOD_PORT with the $HTTPS_NAME certificate: https://$HTTPS_NAME:$VOD_PORT/vod/…"
    else
        warn "On demand files are on plain HTTP until there is a certificate: websites on https cannot play them"
        hint "copy the one for the name viewers use:  sudo $CERT_ME --certificate <name>"
        hint "then:  sudo $ME --vod-https on --https-name <name>"
    fi
fi
# MediaMTX over SSL with the same certificate: RTMPS beside RTMP for
# encoders, and HTTPS for HLS and WebRTC, which a website on https needs to
# play live streams at all. On by default where there is a certificate; off
# is a choice it remembers. MediaMTX gets its own copy, renewed with the
# node's, and picks a renewal up without a restart.
MTX_SSL_SAID=$MTX_SSL
MTX_SSL=${MTX_SSL:-$(prev media.mediamtx.tls)}
case "$MTX_SSL" in
    on|yes|true|1|"") MTX_SSL=true ;;
    off|no|false|0) MTX_SSL="" ;;
    *) die "--mediamtx-tls takes on or off" ;;
esac
if [ "$MEDIA" = nimble ]; then
    case "$MTX_SSL_SAID" in
        ""|off|no|false|0) ;;
        *) die "--mediamtx-tls is for a MediaMTX node. Nimble's SSL is set up in Nimble" ;;
    esac
    MTX_SSL=""
elif [ -n "$MTX_SSL" ]; then
    if [ -z "$HTTPS_NAME" ]; then
        mapfile -t COPIES < <(find "$NODE_TLS" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null)
        [ ${#COPIES[@]} -eq 1 ] && HTTPS_NAME=${COPIES[0]}
    fi
    if [ -z "$HTTPS_NAME" ]; then
        warn "MediaMTX is without SSL until there is a certificate: no RTMPS, and websites on https cannot play its live streams"
        hint "copy the one for the name viewers use:  sudo $CERT_ME --certificate <name>"
        hint "then:  sudo $ME --https-name <name>"
        MTX_SSL_NAME=""
    else
        if [ -n "$PACKAGED" ]; then CERT_JOB_RUN=(/usr/libexec/tak3-node/certificate); else CERT_JOB_RUN=(bash "$(dirname "$0")/certificate.sh"); fi
        TAK3_FOR=node "${CERT_JOB_RUN[@]}" --mediamtx "$HTTPS_NAME" || die "MediaMTX could not be given the $HTTPS_NAME certificate (the reason is above)"
        MTX_SSL_NAME=$HTTPS_NAME
        set_mediamtx_tls "/etc/mediamtx/tls/$HTTPS_NAME" on
    fi
else
    set_mediamtx_tls "" off
fi
if [ -z "$VOD_HTTPS" ] && [ -z "$HTTPS_PORT" ] && [ -z "${MTX_SSL_NAME:-}" ]; then
    HTTPS_NAME=""
fi
# The folders on-demand files may come from: granted here, by root, and
# chosen among in the console. A node without the setting gets its own vod
# folder and the folders its routes already serve, so nothing stops working.
VOD_ROOTS=$(prev vod.allowed-roots)
if [ -z "$VOD_ROOTS" ]; then
    VOD_ROOTS="$INSTALL_DIR/vod"
    if [ -f "$INSTALL_DIR/vod-routes.json" ]; then
        while IFS= read -r d; do
            [ -n "$d" ] && VOD_ROOTS="$VOD_ROOTS,$d"
        done < <(jq -r '.routes[]?.directory // empty' "$INSTALL_DIR/vod-routes.json" 2>/dev/null || true)
    fi
fi
IFS=',' read -r -a WANT_FOLDERS <<< "$VOD_FOLDERS"
for f in "${WANT_FOLDERS[@]+"${WANT_FOLDERS[@]}"}"; do
    f=${f%/}
    [[ $f == /* ]] || die "--vod-folder takes a full path, like /srv/vod"
    case "$f" in /etc|/etc/*|/root|/root/*|/proc*|/sys*|/dev*|/boot*|/run*|/var/run*) die "$f is a system folder: on-demand files are never served from it" ;; esac
    if [ ! -d "$f" ]; then
        install -d -o "$SERVICE_USER" -g "$SERVICE_USER" "$f"
        ok "made $f for on-demand files"
    fi
    case ",$VOD_ROOTS," in *",$f,"*) ;; *) VOD_ROOTS="$VOD_ROOTS,$f" ;; esac
    runuser -u "$SERVICE_USER" -- test -r "$f" || warn "$SERVICE_USER cannot read $f: its files will not be served until it can"
done
VOD_ROOTS=$(printf '%s' "$VOD_ROOTS" | tr ',' '\n' | sed '/^$/d' | awk '!seen[$0]++' | paste -sd, -)
as_service mkdir -p "$INSTALL_DIR/vod"
ok "on-demand files may come from: ${VOD_ROOTS//,/, }"

# The folders an export may be written to, and nowhere else: whoever holds the
# node's key could otherwise name any folder the service can write — its own
# scripts folder among them. Granted here, by root.
EXPORT_ROOTS=$(prev export.folders)
[ -n "$EXPORT_ROOTS" ] || EXPORT_ROOTS="$INSTALL_DIR/mp4,$VOD_ROOTS"
# On a Nimble server, the folders Nimble's own VOD routes serve: the archive
# panel offers exactly those as destinations, and left out they all showed as
# "nowhere writable". Root grants them here, by running setup; a route added
# later is granted at the next run. Never a system folder or the node's own.
if [ "$MEDIA" = nimble ] && [ -r /etc/nimble/rules.conf ]; then
    while IFS= read -r d; do
        d=${d%/}
        [[ $d == /?* ]] || continue
        case "$d" in /etc|/etc/*|/root|/root/*|/proc*|/sys*|/dev*|/boot*|/run*|/var/run*|/usr*|/opt*|/bin*|/sbin*|/lib*) continue ;; esac
        case "$d" in "$INSTALL_DIR"|"$INSTALL_DIR/scripts"|"$INSTALL_DIR/scripts/"*) continue ;; esac
        [ -d "$d" ] || continue
        case ",$EXPORT_ROOTS," in
            *",$d,"*) ;;
            *) EXPORT_ROOTS="$EXPORT_ROOTS,$d"
               runuser -u "$SERVICE_USER" -- test -w "$d" \
                   || warn "$d is served by Nimble but $SERVICE_USER cannot write it: exports there need  sudo chown $SERVICE_USER $d" ;;
        esac
    done < <(jq -r '.routes[]?.origin // empty | select(startswith("file://")) | sub("^file://"; "")' /etc/nimble/rules.conf 2>/dev/null || true)
fi
IFS=',' read -r -a WANT_EXPORTS <<< "$EXPORT_FOLDERS"
for f in "${WANT_EXPORTS[@]+"${WANT_EXPORTS[@]}"}"; do
    f=${f%/}
    [[ $f == /* ]] || die "--export-folder takes a full path, like /srv/exports"
    case "$f" in /etc|/etc/*|/root|/root/*|/proc*|/sys*|/dev*|/boot*|/run*|/var/run*|/usr*|/opt*|/bin*|/sbin*|/lib*) die "$f is a system folder: no export is ever written there" ;; esac
    case "$f" in "$INSTALL_DIR"|"$INSTALL_DIR/scripts"|"$INSTALL_DIR/scripts/"*) die "$f holds the node's own scripts: no export is ever written there" ;; esac
    if [ ! -d "$f" ]; then
        install -d -o "$SERVICE_USER" -g "$SERVICE_USER" "$f"
        ok "made $f for exports"
    fi
    case ",$EXPORT_ROOTS," in *",$f,"*) ;; *) EXPORT_ROOTS="$EXPORT_ROOTS,$f" ;; esac
    runuser -u "$SERVICE_USER" -- test -w "$f" || warn "$SERVICE_USER cannot write $f: exports there will fail until it can"
done
EXPORT_ROOTS=$(printf '%s' "$EXPORT_ROOTS" | tr ',' '\n' | sed '/^$/d' | awk '!seen[$0]++' | paste -sd, -)
ok "exports may be written to: ${EXPORT_ROOTS//,/, }"

# Nimble's stream events carry a key: on a new Nimble node, and when asked for.
# Kept as a digest, like the API keys: shown once, when it is made.
PUSH_DIGEST=$(prev pushSecret)
PUSH_SECRET=""
if [ -n "$PUSH_DIGEST" ] && ! is_digest "$PUSH_DIGEST"; then
    [ -n "$ROTATED" ] || PUSH_SECRET=$PUSH_DIGEST
    PUSH_DIGEST=$(digest "$PUSH_DIGEST")
fi
if [ "$MEDIA" = nimble ] && { [ "${NEW_PUSH_SECRET:-}" = yes ] || { [ -z "$PUSH_DIGEST" ] && [ -z "$PREV_SRC" ]; }; }; then
    PUSH_SECRET=$(newkey); PUSH_DIGEST=$(digest "$PUSH_SECRET")
    ok "stream events from Nimble need a new key: it is in the push address below"
elif [ -z "$PUSH_DIGEST" ] && [ "$MEDIA" = nimble ]; then
    hint "stream events from Nimble need no key on this node; NEW_PUSH_SECRET=yes gives them one (then update Nimble's push address)"
fi
# Someone else on :$PORT would answer the health check below and make this
# script report success while the node is crash-looping on "port in use".
if ss -ltn "sport = :$PORT" 2>/dev/null | grep -q LISTEN; then
    if ! systemctl is-active --quiet "$SERVICE"; then
        OCCUPANT=$(ss -ltnp "sport = :$PORT" 2>/dev/null | awk 'NR==2 {print $NF}')
        die "port $PORT is already in use by $OCCUPANT
   Re-run on a free port:  sudo PORT=8090 $ME"
    fi
fi
ok "port $PORT"
TRANSCODE_FLAG=false; [ "$TRANSCODE" = "yes" ] && TRANSCODE_FLAG=true

if [ "$MEDIA" != nimble ]; then
    MTX_SEALED=$(seal "$MTX_PASS") || die "could not seal the MediaMTX password with $SECRET_KEY"
fi
# The settings, one per line, the same whether they end up as a properties file
# (package) or as flags on the unit (script install).
SETTINGS="scriptPath=$INSTALL_DIR/scripts
server.port=$PORT
server.address=$LISTEN
vod.allowed-roots=$VOD_ROOTS
export.folders=$EXPORT_ROOTS
web.authentication.apikey=$API_DIGEST
readOnlyApiKey=$RO_DIGEST
transcoderEnabled=$TRANSCODE_FLAG
transcoderStore=$INSTALL_DIR/transcoders.json
transcoder.default-image=$IMAGE
media.server=$MEDIA"
if [ "$TRANSCODE" = "yes" ]; then
    SETTINGS="$SETTINGS
transcoder.docker-command=sudo -n $HELPER"
fi
if [ "$MEDIA" = nimble ]; then
    SETTINGS="$SETTINGS
salt=$SALT
hash=$HASH
managementUrlAndPort=$MGMT"
else
    SETTINGS="$SETTINGS
vod.port=$VOD_PORT
media.mediamtx.user=$MTX_USER
media.mediamtx.password=$MTX_SEALED"
    if [ "$RTMP_PORT" != 1935 ]; then
        SETTINGS="$SETTINGS
transcoder.nimble-rtmp-url=rtmp://127.0.0.1:$RTMP_PORT"
    fi
    if [ "$RTSP_PORT" != 8554 ]; then
        SETTINGS="$SETTINGS
media.republish-source=rtsp://127.0.0.1:$RTSP_PORT"
    fi
fi
if [ -n "$INSTANCE" ]; then
    # Its name on this machine: its containers carry it, so the node beside
    # it never takes them for strays.
    SETTINGS="$SETTINGS
node.instance=$INSTANCE"
fi
if [ -n "$METRICS_PORT" ]; then
    SETTINGS="$SETTINGS
tak3.metrics.port=$METRICS_PORT"
fi
if [ -n "$FORWARD" ]; then
    SETTINGS="$SETTINGS
eventForwardUrl=$FORWARD"
fi
if [ -n "$PUSH_DIGEST" ]; then
    SETTINGS="$SETTINGS
pushSecret=$PUSH_DIGEST"
fi
if [ -n "$HTTPS_PORT" ]; then
    SETTINGS="$SETTINGS
node.https.port=$HTTPS_PORT"
fi
if [ "$MEDIA" != nimble ]; then
    # Written either way: the node's default is HTTPS, and off is a choice.
    SETTINGS="$SETTINGS
vod.https=$([ -n "$VOD_HTTPS" ] && echo true || echo false)
media.mediamtx.tls=$([ -n "$MTX_SSL" ] && echo true || echo false)"
fi
if [ -n "$HTTPS_NAME" ] && { [ -n "$HTTPS_PORT" ] || [ -n "$VOD_HTTPS" ] || [ -n "${MTX_SSL_NAME:-}" ]; }; then
    SETTINGS="$SETTINGS
node.https.certificate=$HTTPS_NAME"
fi

if [ -n "$PACKAGED" ]; then
    install -d -m 750 -o root -g "$SERVICE_USER" /etc/tak3-node "$(dirname "$CONFIG")"
    if [ -f "$CONFIG" ]; then cp -p "$CONFIG" "$CONFIG.before-setup.$(date +%s)"; fi
    {
        echo "# tak3 node — written by tak3-node-setup on $(date -u '+%Y-%m-%d %H:%M UTC')."
        echo "# Re-run it to change the answers; a line it does not write is kept."
        printf '%s\n' "$SETTINGS"
        printf '%s\n' "$CARRY" | sed '/^$/d'
    } > "$CONFIG.new"
    chown root:"$SERVICE_USER" "$CONFIG.new"
    chmod 640 "$CONFIG.new"
    mv "$CONFIG.new" "$CONFIG"
    ok "wrote $CONFIG"
    if [ "$PREV_SRC" = unit ]; then
        # The script install's unit would override the package's. Its settings
        # are in the file above now, so it is set aside, not deleted.
        mv "$UNIT" "/root/$SERVICE.script-install.$(date +%s)"
        rm -f /etc/apt/apt.conf.d/99-tak3-restart-after-java
        ok "moved from the script install: its unit is kept in /root, its settings are above"
    fi
else
    if [ -f "$UNIT" ]; then cp "$UNIT" "/root/$SERVICE.bak.$(date +%s)"; fi
    # A value with a space in it (the docker command) is quoted, or systemd
    # would hand it to the node as three arguments.
    FLAGS=$(printf '%s\n' "$SETTINGS" "$CARRY" | sed '/^$/d; s/^/--/; /[[:space:]]/{s/"/\\"/g; s/^/"/; s/$/"/;}' | tr '\n' ' ')
    cat > "$UNIT" <<EOF
[Unit]
Description=tak3 node
After=network.target docker.service mediamtx.service

[Service]
User=$SERVICE_USER
Group=$SERVICE_USER
ExecStart=/usr/bin/java -jar $LINK ${FLAGS% }
SuccessExitStatus=143
WorkingDirectory=$INSTALL_DIR
SyslogIdentifier=tak3-node
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
    ok "wrote $UNIT"
fi

# --- 8. start ---------------------------------------------------------------
# On a script install the runtime is the distribution's Java, and patching it
# while this service runs replaces the helper every process is started
# through: exports and stream scripts then fail until a restart. This hook
# restarts the node after an apt run, and only when its runtime changed. The
# package carries its own runtime and needs none of this.
install_java_guard() {
    mkdir -p /usr/local/lib/tak3
    cat > /usr/local/lib/tak3/restart-if-java-changed.sh <<'HOOK'
#!/bin/sh
# Restarts a tak3 service when its Java runtime has been replaced since it
# started. Installed by the tak3 installers; safe to remove.
set -e
for svc in tak3-node.service tak3-console.service; do
    systemctl is-active --quiet "$svc" 2>/dev/null || continue
    pid=$(systemctl show -p MainPID --value "$svc" 2>/dev/null || echo 0)
    [ -n "$pid" ] && [ "$pid" != 0 ] || continue
    java=$(readlink -f "/proc/$pid/exe" 2>/dev/null) || continue
    helper="$(dirname "$java")/../lib/jspawnhelper"
    [ -f "$helper" ] || continue
    started=$(systemctl show -p ActiveEnterTimestamp --value "$svc" 2>/dev/null) || continue
    [ -n "$started" ] || continue
    started_at=$(date -d "$started" +%s 2>/dev/null) || continue
    replaced_at=$(stat -c %Y "$helper" 2>/dev/null) || continue
    [ "$replaced_at" -gt "$started_at" ] || continue
    logger -t tak3 "java runtime replaced since $svc started; restarting so it can run processes again"
    systemctl restart "$svc" || true
done
HOOK
    chmod 755 /usr/local/lib/tak3/restart-if-java-changed.sh
    cat > /etc/apt/apt.conf.d/99-tak3-restart-after-java <<'APT'
// A Java upgrade replaces the runtime under a running service, after which it
// can start no processes at all — exports and stream scripts fail until it is
// restarted. The script restarts a tak3 service only when that has happened.
DPkg::Post-Invoke { "if [ -x /usr/local/lib/tak3/restart-if-java-changed.sh ]; then /usr/local/lib/tak3/restart-if-java-changed.sh || true; fi"; };
APT
    chmod 644 /etc/apt/apt.conf.d/99-tak3-restart-after-java
}

say "Starting" "enabled at boot and started now"
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null 2>&1 || true
if [ -z "$PACKAGED" ]; then
    install_java_guard
    ok "a java upgrade will restart this service instead of leaving it unable to run scripts"
fi
systemctl restart "$SERVICE"
sleep 4

# --- 9. verify end to end ---------------------------------------------------
say "Verifying" "proving the service runs, reaches the media server, and refuses calls without a key"
systemctl is-active --quiet "$SERVICE" || die "service is not running — journalctl -u $SERVICE -n 30"
ok "service active and enabled at boot"

for _ in $(seq 1 30); do
    curl -sf --max-time 3 "http://127.0.0.1:$PORT/actuator/health" >/dev/null 2>&1 && break
    sleep 1
done
curl -sf --max-time 5 "http://127.0.0.1:$PORT/actuator/health" >/dev/null \
    && ok "health endpoint up" || die "health endpoint not responding — journalctl -u $SERVICE -n 30"

# Checks that need a key run with one made in this run; a key from before is
# known only to the consoles that hold it.
if [ -n "$API_KEY" ]; then
    if curl -sf --max-time 5 "http://127.0.0.1:$PORT/api/server-status" -H "X-Api-Key: $API_KEY" | grep -q '{'; then
        ok "node reaches $MEDIA"
    else
        die "node cannot reach $MEDIA — journalctl -u $SERVICE -n 30"
    fi
else
    ok "the full-control key is the one the console holds; this run checked $MEDIA itself, above"
fi

UNAUTH=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$PORT/api/dvr")
[ "$UNAUTH" = "401" ] && ok "API key filter rejects unauthenticated calls" || warn "expected 401 without a key, got $UNAUTH"
if [ -n "$RO_KEY" ]; then
    RO_WRITE=$(curl -s -o /dev/null -w '%{http_code}' -X POST "http://127.0.0.1:$PORT/api/transcoders/x/pause" -H "X-Api-Key: $RO_KEY")
    [ "$RO_WRITE" = "403" ] && ok "read-only key is refused on writes" || warn "expected 403 for a read-only write, got $RO_WRITE"
fi
SETTINGS_FILE=${CONFIG:-$UNIT}
LEAKED=""
for secret in "$API_KEY" "$RO_KEY" "$PUSH_SECRET" "$([ "$MEDIA" = nimble ] || printf '%s' "$MTX_PASS")"; do
    [ -n "$secret" ] && grep -qF -- "$secret" "$SETTINGS_FILE" 2>/dev/null && LEAKED=yes
done
if [ -n "$LEAKED" ]; then
    warn "a key or password of tak3's is readable in $SETTINGS_FILE — this should not happen"
else
    ok "no key or password of tak3's is readable in $SETTINGS_FILE"
fi

if [ "$TRANSCODE" = "yes" ] && [ -n "$API_KEY" ]; then
    DOCKER_OK=$(curl -sf --max-time 8 "http://127.0.0.1:$PORT/api/transcoders" -H "X-Api-Key: $API_KEY" | grep -o '"dockerAvailable":[a-z]*' | cut -d: -f2 || true)
    [ "$DOCKER_OK" = "true" ] && ok "node can run containers through $HELPER" \
        || warn "node cannot run containers yet — test it: sudo -u $SERVICE_USER sudo -n $HELPER version --format '{{.Server.Version}}'"
fi

PUBLIC_IP=$(curl -4 -s --max-time 5 ifconfig.me || echo '<this-server-ip>')

# --- 10. pairing ------------------------------------------------------------
# The console calls the node back on each of these, in this order, with the key
# sent here, and keeps the first that answers as this node.
PAIRED=""
if [ -n "$PAIR" ]; then
    say "Pairing with the console" "sends the code, this node's key and where it can be reached; the console calls back to check"
    # Pairing sends this node's key, so it happens over the tailnet or on this
    # machine, never across the internet: a server reached any other way is
    # added by hand in the console instead.
    CANDIDATES=()
    [ -n "$ADDRESS" ] && CANDIDATES+=("$ADDRESS")
    CANDIDATES+=("http://127.0.0.1:$PORT")
    [ -n "$TAILNET_IP" ] && [ "$LISTEN" != 127.0.0.1 ] && CANDIDATES+=("http://$TAILNET_IP:$PORT")
    # Across the internet: over HTTPS, at the certificate's name.
    [ -n "$HTTPS_PORT" ] && [[ $HTTPS_NAME != wildcard* ]] && CANDIDATES+=("https://$HTTPS_NAME:$HTTPS_PORT")
    NODE_VERSION=$(dpkg-query -W -f='${Version}' tak3-node 2>/dev/null || basename "${JAR:-?}")
    BODY=$(jq -n --arg code "$PAIR_CODE" --arg key "$API_KEY" --arg media "$MEDIA" --arg instance "${INSTANCE:-default}" \
        --arg version "$NODE_VERSION" --arg host "$(hostname -f 2>/dev/null || hostname)" \
        '{code: $code, apiKey: $key, media: $media, instance: $instance, version: $version, host: $host,
          candidates: $ARGS.positional}' --args "${CANDIDATES[@]}")
    REPLY_FILE=$(mktemp); CURL_ERR=$(mktemp)
    CODE=$(printf '%s' "$BODY" | curl -sS -o "$REPLY_FILE" -w '%{http_code}' --max-time 60 \
        -H 'Content-Type: application/json' --data-binary @- "$CONSOLE_URL/pair" 2>"$CURL_ERR" || true)
    MESSAGE=$(jq -r '.message // empty' "$REPLY_FILE" 2>/dev/null || true)
    if [ "$CODE" = 200 ]; then
        PAIRED=$(jq -r '.server // empty' "$REPLY_FILE")
        ok "${MESSAGE:-paired as $PAIRED}"
    else
        # With no answer at all, curl's own words say why: a certificate, a
        # closed port, a name that does not resolve. "000" said nothing.
        WHY=$MESSAGE
        if [ -z "$WHY" ]; then
            CURL_SAID=$(sed -E 's/^curl: \([0-9]+\) //' "$CURL_ERR" | tail -n 1 | cut -c1-200)
            WHY="the console did not answer at $CONSOLE_URL/pair${CURL_SAID:+ — $CURL_SAID}"
        fi
        [ "$CODE" = 000 ] && CODE=""
        warn "not paired${CODE:+ ($CODE)}: $WHY"
        # A failed pairing must not cost the console that already held this
        # node its key: the one made for pairing goes, the old one comes back.
        if [ -n "$PAIR_OLD_DIGEST" ]; then
            sed -i "s|^web.authentication.apikey=.*|web.authentication.apikey=$PAIR_OLD_DIGEST|" "$CONFIG"
            if systemctl restart "$SERVICE" 2>/dev/null; then
                ok "the previous full-control key is back: a console that held it keeps this node"
            else
                warn "the previous key is written back, but $SERVICE did not restart:  sudo systemctl restart $SERVICE"
            fi
            API_KEY=""; API_DIGEST=$PAIR_OLD_DIGEST
        fi
        # A console on this very machine is reached at its own address, with no
        # internet, certificate or firewall in between.
        LOCAL_CONSOLE=""
        if [ -r /etc/default/tak3-console ]; then
            CPORT=$(grep -o -- '--server.port=[0-9]*' /etc/default/tak3-console | head -n 1 | cut -d= -f2)
            CADDR=$(grep -o -- '--server.address=[^ "]*' /etc/default/tak3-console | head -n 1 | cut -d= -f2)
            case "$CADDR" in ''|0.0.0.0|::) CADDR=127.0.0.1 ;; esac
            [ -n "$CPORT" ] && LOCAL_CONSOLE="http://$CADDR:$CPORT"
        fi
        if [ -n "$LOCAL_CONSOLE" ] && [ "$CONSOLE_URL" != "$LOCAL_CONSOLE" ]; then
            hint "the console runs on this machine: pair with its own address, which needs no internet:"
            hint "    sudo $ME --pair $LOCAL_CONSOLE/pair/$PAIR_CODE"
            hint "(the same code works until it runs out; otherwise make a new one in the console)"
        else
            hint "this node is set up and running; pair it again with a new code:"
            hint "    sudo $ME --pair <the address the console shows>"
        fi
    fi
    rm -f "$REPLY_FILE" "$CURL_ERR"
fi

# --- what to do next --------------------------------------------------------
if [ -n "$PACKAGED" ]; then
    UPDATE="sudo apt update && sudo apt install tak3-node"
    REMOVE="sudo apt remove tak3-node"
    WHERE="settings : $CONFIG"
else
    UPDATE="sudo bash update-node.sh <new jar>"
    REMOVE="sudo bash uninstall-node.sh"
    WHERE="settings : $UNIT"
fi
if [ "$MEDIA" = nimble ]; then
    NIMBLE_HTTP=$(grep -oP '^\s*port\s*=\s*\K\S+' "$NIMBLE_CONF" | head -1 || echo '?')
    NIMBLE_SSL=$(grep -oP '^\s*ssl_port\s*=\s*\K\S+' "$NIMBLE_CONF" | head -1 || echo '-')
    VIEWER_PORTS="   Nimble HTTP port   : $NIMBLE_HTTP        (viewers)
   Nimble SSL port    : $NIMBLE_SSL        (viewers, TLS)"
    FIREWALL="Nimble's viewer ports for everyone"
    [ "$LISTEN" = 0.0.0.0 ] && FIREWALL="tcp $PORT from the console host ONLY; $FIREWALL"
    [ -n "$HTTPS_PORT" ] && FIREWALL="tcp $HTTPS_PORT (HTTPS) for the console; $FIREWALL"
    NEXT=3
else
    if [ -n "${MTX_SSL_NAME:-}" ]; then
        MTX_PUB="RTMP $RTMP_PORT, RTMPS $(mtx_port rtmpsAddress 1936) (SSL), SRT $SRT_PORT/udp, RTSP $RTSP_PORT (publishers)"
        MTX_VIEW="HLS $HLS_PORT and WebRTC $WEBRTC_PORT over HTTPS, WebRTC media $WEBRTC_UDP_PORT/udp (viewers)"
    else
        MTX_PUB="RTMP $RTMP_PORT, SRT $SRT_PORT/udp, RTSP $RTSP_PORT (publishers)"
        MTX_VIEW="HLS $HLS_PORT, WebRTC $WEBRTC_PORT, WebRTC media $WEBRTC_UDP_PORT/udp (viewers)"
    fi
    VIEWER_PORTS="   MediaMTX           : $MTX_PUB
                        $MTX_VIEW
   On demand files    : $VOD_PORT $(if [ -n "$VOD_HTTPS" ] && [ -n "$HTTPS_NAME" ]; then echo "(HTTPS, https://$HTTPS_NAME:$VOD_PORT)"; else echo "(plain HTTP)"; fi)"
    FIREWALL="the MediaMTX ports above and $VOD_PORT for everyone who publishes or watches"
    [ "$LISTEN" = 0.0.0.0 ] && FIREWALL="tcp $PORT from the console host ONLY; $FIREWALL"
    [ -n "$HTTPS_PORT" ] && FIREWALL="tcp $HTTPS_PORT (HTTPS) for the console; $FIREWALL"
    NEXT=2
fi

cat <<EOF

────────────────────────────────────────────────────────────
 tak3 node set up and verified.${INSTANCE:+
   node               : $INSTANCE (tak3-node@$INSTANCE, beside the main tak3-node)}
   media server       : $MEDIA
   public IP          : $PUBLIC_IP
   full-control key   : ${API_KEY:-kept (the console holds it; this node keeps only a digest)}
   read-only key      : ${RO_KEY:-kept (as a digest only)}
   transcoding        : $TRANSCODE$([ "$TRANSCODE" = "yes" ] && echo " ($IMAGE, declarations in $INSTALL_DIR/transcoders.json)")
$VIEWER_PORTS

   $WHERE
   logs     : journalctl -u $SERVICE -f
   metrics  : curl -s http://127.0.0.1:${METRICS_PORT:-9180}/metrics   (this machine only)
   update   : $UPDATE
   remove   : $REMOVE

 Next, off this machine:

 1. Firewall: $FIREWALL.
    The console lists them again under Servers › Listeners & access.
    If the provider runs a firewall in front of this server (a cloud panel
    or security group), open them there too: ufw here is not enough.
EOF
if [ "$MEDIA" = nimble ]; then
    PUSH_QUERY=""
    if [ -n "$PUSH_SECRET" ]; then PUSH_QUERY="?key=$PUSH_SECRET"
    elif [ -n "$PUSH_DIGEST" ]; then PUSH_QUERY="?key=<its push secret, unchanged>"
    fi
    cat <<EOF

 2. Nimble's push API for this server — set it in the panel that manages
    Nimble, or in nimble.conf:
       http://127.0.0.1:$PORT/nimble/events$PUSH_QUERY
EOF
    if [ -n "$PUSH_SECRET" ]; then
        echo "    The key is shown once: this node keeps only a digest of it."
    elif [ -n "$PUSH_DIGEST" ]; then
        echo "    A new push secret: sudo NEW_PUSH_SECRET=yes $ME, then update that address."
    fi
fi
if [ -n "$PAIRED" ]; then
    cat <<EOF

 $NEXT. Nothing to add in the console: this node is the server $PAIRED there.
────────────────────────────────────────────────────────────
EOF
    exit 0
fi
# Keys kept from an earlier run: a console that had this node still has it.
if [ -z "$API_KEY" ]; then
    ADD_LEAD="Already a server in your console? Nothing to add: its keys were kept.
    To add it to a console: Servers › Add server makes a code; then here"
else
    ADD_LEAD="In the console: Servers › Add server makes a code; then here"
fi
cat <<EOF

 $NEXT. $ADD_LEAD
        sudo $ME --pair <the address it shows>
    Not on the tailnet: Servers › Add server › Enter it by hand, with
    this node's address and full-control key.$([ -n "$API_KEY" ] || printf '\n    The key is not kept here: sudo %s --new-keys makes new ones, shown once.' "$ME")
    Or, in the console's configuration on the console host:
        - name: <short-name>
          base-url: $(if [ -n "$HTTPS_PORT" ]; then echo "https://$HTTPS_NAME:$HTTPS_PORT"; elif [ "$LISTEN" = 0.0.0.0 ]; then echo "http://$PUBLIC_IP:$PORT"; else echo "http://$LISTEN:$PORT"; fi)
          api-key: "${API_KEY:-<its full-control key>}"            # full control
    For a box the console may only watch, use the read-only key and add
    manage: false  — it can then never be changed from there.
    Then:  sudo tak3-console-setup   (it seals the key in that file and restarts the console)
────────────────────────────────────────────────────────────
EOF
